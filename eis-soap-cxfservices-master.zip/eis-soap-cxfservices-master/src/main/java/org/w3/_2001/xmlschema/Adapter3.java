package org.w3._2001.xmlschema;

import java.util.Calendar;
import javax.xml.bind.DatatypeConverter;
import javax.xml.bind.annotation.adapters.XmlAdapter;

public class Adapter3 extends XmlAdapter<String, Calendar> {
  public Calendar unmarshal(String paramString) {
    return DatatypeConverter.parseDate(paramString);
  }
  
  public String marshal(Calendar paramCalendar) {
    if (paramCalendar == null)
      return null; 
    return DatatypeConverter.printDate(paramCalendar);
  }
}
