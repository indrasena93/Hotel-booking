package org.w3._2001.xmlschema;

import java.util.Calendar;
import javax.xml.bind.DatatypeConverter;
import javax.xml.bind.annotation.adapters.XmlAdapter;

public class Adapter2 extends XmlAdapter<String, Calendar> {
  public Calendar unmarshal(String paramString) {
    return DatatypeConverter.parseDateTime(paramString);
  }
  
  public String marshal(Calendar paramCalendar) {
    if (paramCalendar == null)
      return null; 
    return DatatypeConverter.printDateTime(paramCalendar);
  }
}
