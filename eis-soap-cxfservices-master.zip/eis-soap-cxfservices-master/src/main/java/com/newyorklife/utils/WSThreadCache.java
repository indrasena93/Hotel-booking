package com.newyorklife.utils;

import java.util.HashMap;

public class WSThreadCache {
private static final WSThreadCache instance = new WSThreadCache();
	
	private WSThreadCache() {}

	public static WSThreadCache getInstance() {
		return instance;
	}
	
	/*
	 * InheritableThreadLocal variable to hold the map of values.
	 */
	@SuppressWarnings("rawtypes")
	private static InheritableThreadLocal threadLocal = new InheritableThreadLocal() {
		protected Object initialValue() {
			return new HashMap<Object, Object>();
		}
	};
	
	/**
	 * Returns the object associated to the provided key in the cache
	 * @param key Object
	 * @return value Object
	 */
	public Object get(Object key) {
		@SuppressWarnings("unchecked")
		HashMap<Object, Object> cache = (HashMap<Object, Object>) threadLocal.get();
		return cache.get(key);
	}
	
	/**
	 * Stores an object in the current thread's cache.
	 * @param key Object
	 * @param value Object
	 */
	public void put(Object key, Object value) {
		@SuppressWarnings("unchecked")
		HashMap<Object, Object> cache = (HashMap<Object, Object>) threadLocal.get();
		cache.put(key, value);
	}
	
	/**
	 * Removes the object associated to the provided key from the cache.
	 * @param key Object
	 * @return value Object - removed Object
	 */
	public Object remove(Object key) {
		@SuppressWarnings("rawtypes")
		HashMap cache = (HashMap) threadLocal.get();
		return cache.remove(key);
	}
	
	/**
	 * Clears the existing thread's cache. This method should not be used
	 * by the applications, as it will clear some of the framework's
	 * internal configration.
	 */
	public void clear() {
		@SuppressWarnings("rawtypes")
		HashMap cache = (HashMap) threadLocal.get();
		cache.clear();
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
