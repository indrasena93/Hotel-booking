package com.newyorklife.utils;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.io.StringReader;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *	Author: Chloe Wong		Date: Sep 19, 2014
 */

public class JaxbUtil {
	private static final Logger log = LoggerFactory.getLogger(JaxbUtil.class);
	
	public static String getXmlStringFromMarshal(Object jaxbObj) {
		log.info("Start Get XML String from Jaxb Marshalling...");
		
		JAXBContext jc = null;
		Marshaller ms = null;
		
		OutputStream outStr = null;
		String retStr = null;
		
		if (jaxbObj == null) {
			return null;
		}
		
		try {
			jc = JAXBContext.newInstance("com.newyorklife.jaxb");
			
			ms = jc.createMarshaller();
			
			outStr = new ByteArrayOutputStream();
			
			ms.marshal(jaxbObj, outStr);
			
			retStr = outStr.toString();
			
		}catch (Exception e) {
			e.printStackTrace();
			log.error("JAXB can not Marshall Object [{}] to XML String", jaxbObj.toString());
			retStr = null;
		}
		
		return retStr;
	}
	
	
	public static Object getObjectFromUnmarshalXmlString(String xmlStr) {
		log.info("Start Get Object from Jaxb UnMarshalling XML String ...");
		
		JAXBContext jc = null;
		Unmarshaller um = null;
		
		Object retObj = null;
		
		if (xmlStr == null) {
			return null;
		}
		
		try {
			jc = JAXBContext.newInstance("com.newyorklife.jaxb");
			
			um = jc.createUnmarshaller();
			
			retObj = um.unmarshal(new StreamSource(new StringReader(xmlStr)));
			
		}catch (Exception e) {
			e.printStackTrace();
			log.error("JAXB can not UnMarshall XMLString [{}] to Object", xmlStr);
			retObj = null;
		}
		
		return retObj;
	}
}
