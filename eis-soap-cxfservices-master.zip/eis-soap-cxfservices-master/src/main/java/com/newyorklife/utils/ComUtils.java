package com.newyorklife.utils;

/**
 *	Author: Chloe Wong		Date: Nov 26, 2014
 */

public class ComUtils {
	
	public static boolean isNullValue(String inStr) {
		boolean isNullVal = false;
		
		if (inStr != null && inStr.trim().length() > 0) {
			isNullVal = false;
		}else {
			isNullVal = true;
		}
		
		return isNullVal;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
