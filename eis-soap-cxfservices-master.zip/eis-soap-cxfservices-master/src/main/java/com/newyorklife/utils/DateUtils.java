package com.newyorklife.utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *	Author: Chloe Wong		Date: Jun 20, 2014
 */

public class DateUtils {
	//private static final Logger log = Logger.getLogger(DateUtils.class);
	private static final Logger log = LoggerFactory.getLogger(DateUtils.class);
	
	
	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	
	private static DatatypeFactory df = null;
	
	static {
		try {
			df = DatatypeFactory.newInstance();
		}catch(Exception e) {
			e.printStackTrace();
			log.error("Error while trying to obtain a new instance of DatatypeFactory");
		}
	}
	
	public static String convertDate2String(Date dateIn) {
		if (dateIn == null) {
			return null;
		}
		
		return sdf.format(dateIn);
	}
	
	public static String convertDate2String(Date dateIn, String dateFormat) {
		if (dateIn == null) {
			return null;
		}
		
		SimpleDateFormat lsdf = null;
		
		if (dateFormat == null) {
			lsdf = sdf;
		}else {
			lsdf = new SimpleDateFormat(dateFormat);
		}
		
		return lsdf.format(dateIn);
	}
	
	public static Date convertString2Date(String dateStr) {
		Date dateOut = null;
		
		if (dateStr == null) {
			return null;
		}
		
		try {
			
			dateOut = sdf.parse(dateStr);
			
		}catch(Exception e) {
			e.printStackTrace();
			//log.error("Can not convertString2Date for [" + dateStr + "]...");
			log.error("Can not convertString2Date for [{}]...", dateStr);
			dateOut = null;
		}
		
		return dateOut;
	}
	
	public static Date convertString2Date(String dateStr, String dateFormat) {
		Date dateOut = null;
		
		if (dateStr == null) {
			return null;
		}
		
		SimpleDateFormat lsdf = null;
		
		if (dateFormat == null) {
			lsdf = sdf;
		}else {
			lsdf = new SimpleDateFormat(dateFormat);
		}
		
		try {
			
			dateOut = lsdf.parse(dateStr);
			
		}catch(Exception e) {
			e.printStackTrace();
			//log.error("Can not convertString2Date for [" + dateStr + "]...");
			log.error("Can not convertString2Date for [{}]...", dateStr);
			dateOut = null;
		}
		
		return dateOut;
	}
	
	public static Calendar convertDate2Calendar(Date dateIn) {
		if (dateIn == null) {
			return null;
		}
		
		Calendar cal = Calendar.getInstance();
		cal.setTime(dateIn);
		
		return cal;
	}
	
	public static XMLGregorianCalendar getXmlGregorianCalendarFromDate(Date dt) {
		
		if (dt == null) {
			return null;
		}
		
		GregorianCalendar gc = new GregorianCalendar();
		
		gc.setTime(dt);
		//gc.setTimeInMillis(dt.getTime());
		
		return df.newXMLGregorianCalendar(gc);
		
	}
	
	public static Date getDateFromXmlGregorianCalendar(XMLGregorianCalendar xmlGC) {
		
		if (xmlGC == null) {
			return null;
		}
		
		return xmlGC.toGregorianCalendar().getTime();
		
	}
	
	public static Calendar convertDate2Calendar(Date dateIn, boolean useTimeZone) {
		if (dateIn == null) {
			return null;
		}
		
		Calendar cal = Calendar.getInstance();
		
		TimeZone tz = TimeZone.getTimeZone("GMT"); //GMT, UTC
		cal.setTimeZone(tz);
		
		cal.setTime(dateIn);
		
		return cal;
	}
	
	public static Date convertCalendar2Date(Calendar dateIn) {
		if (dateIn == null) {
			return null;
		}
		
		return dateIn.getTime();
	}
	
	public static int getCurrentYear() {
		int retYear = -1;
		
		Calendar cal = Calendar.getInstance();
		
		cal.setTime(new Date());
		
		retYear = cal.get(Calendar.YEAR);
		
		return retYear;
	}

}
