package com.newyorklife.utils;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.StringTokenizer;

import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.xml.DOMConfigurator;

import com.newyorklife.admin.WSApplicationContext;

public class WSInitUtil {
	private static final String APP_CONFIG_FILE = "app_config.properties";
	private static final String BEANS_CONFIG_XML = "bean.config.xmls";
	private static final String DATABASE_TYPE = "database.type";
	
	private String env = null;
	private Properties appCfgProp = null;
	private Properties dbCfgProp = null;
	private String dbCfgFile = null;
	private String logCfgFile = null;
	private Properties logCfgProp = null;
	private String beansUrlStr = null;
	private List<String> beansUrls = null;
	private String appName = null;
	private String dbType = null;
	
	private ClassLoader cl = WSApplicationContext.getInstance().getApplicationClassLoader();
	
	public WSInitUtil() {
		
	}
	
	public void init() {
		System.out.println("WSInitUtil Start " + getAppName() + " initialization ...");
		
		appCfgProp = new Properties();
		InputStream input = null;
		
		
		try {
			
			input = cl.getResourceAsStream(APP_CONFIG_FILE);
			
			if (input == null) {
				logCfgFile = "log4j.properties";
			}else {
				appCfgProp.load(input);
				//PropertyConfigurator.configure(appCfgProp);
				
				//setEnv(appCfgProp.getProperty("env"));
				//setLogCfgFile(appCfgProp.getProperty(LOG_CONFIG_FILE));
				setBeansUrlStr(appCfgProp.getProperty(BEANS_CONFIG_XML));
				//setDbCfgFile(appCfgProp.getProperty(DB_CONFIG_FILE));
				setDbType(appCfgProp.getProperty(DATABASE_TYPE));
			}
			
			if (env == null || env.isEmpty()) {
				env = appCfgProp.getProperty("env");
				env = (env == null ? "unit": env);
			}
			
			setEnv(env);
			
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println("Can not initialize app_config.properties file due to " + e.getMessage());
		}finally {
			try {
				if (input != null) {
					input.close();
				}
			}catch (IOException ioe) {
				ioe.printStackTrace();
				System.out.println("Can not close inputStream for app_config.properties file due to " + ioe.getMessage());
			}
		}
		
		//System.out.println("Log4j log file: " + getLogCfgFile());
		
		//System.out.println("Application Name: " + getAppName());
		
		WSApplicationContext.getCxtMap().put(WSConstants.APPLICATION_NAME, getAppName());

		WSApplicationContext.getCxtMap().put(WSConstants.ENV, getEnv());
		
		if (getBeansUrlStr() != null) {
			StringTokenizer tStr = new StringTokenizer(getBeansUrlStr(), ";");
			
			beansUrls = new ArrayList<String>();
			
			while (tStr.hasMoreTokens()) {
				String bUrl = tStr.nextToken();
				beansUrls.add(bUrl);
			}

		}
		
		WSApplicationContext.getCxtMap().put(WSConstants.BEANS_URLS, getBeansUrls());
		
		WSApplicationContext.getCxtMap().put(WSConstants.DATABASE_TYPE, getDbType());
		
		//initLogConfig();
		
		//initDbConfig();
	}
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
	}

	public String getEnv() {
		return env;
	}

	public void setEnv(String env) {
		this.env = env;
	}

	public Properties getAppCfgProp() {
		return appCfgProp;
	}

	public void setAppCfgProp(Properties appCfgProp) {
		this.appCfgProp = appCfgProp;
	}

	public String getLogCfgFile() {
		return logCfgFile;
	}

	public void setLogCfgFile(String logCfgFile) {
		this.logCfgFile = logCfgFile;
	}

	public List<String> getBeansUrls() {
		return beansUrls;
	}

	public void setBeansUrls(List<String> beansUrls) {
		this.beansUrls = beansUrls;
	}

	public String getBeansUrlStr() {
		return beansUrlStr;
	}

	public void setBeansUrlStr(String beansUrlStr) {
		this.beansUrlStr = beansUrlStr;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public Properties getDbCfgProp() {
		return dbCfgProp;
	}

	public void setDbCfgProp(Properties dbCfgProp) {
		this.dbCfgProp = dbCfgProp;
	}

	public String getDbCfgFile() {
		return dbCfgFile;
	}

	public void setDbCfgFile(String dbCfgFile) {
		this.dbCfgFile = dbCfgFile;
	}

	public String getDbType() {
		return dbType;
	}

	public void setDbType(String dbType) {
		this.dbType = dbType;
	}
	
}
