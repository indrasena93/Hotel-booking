package com.newyorklife.utils;

public interface WSConstants {
	public static final String ENV = "ENV";
	public static final String BEANS_URLS = "BeansUrls";
	public static final String APPLICATION_NAME = "ApplicationName";
	public static final String SKEY = "nylkey12nylkey12";
	
	//oracle database constants
	public static final String DB_CONFIG_FILE = "database.config.file";
	public static final String ORACLE_DRIVER = "ORACLE_DRIVER";
	public static final String ORACLE_URL = "ORACLE_URL";
	public static final String USER_NAME = "USER_NAME";
	public static final String PASSWORD = "PASSWORD";
	public static final String POOL_COUNT = "POOL_COUNT";
	public static final String DATASOURCE_NAME = "DATASOURCE_NAME";
	public static final String DATABASE_TYPE = "DATABASE_TYPE";
	
	//database name
	public static final String DATA_SOURCE = "dataSource";
	
	//result status
	public static final String SUCCESS_STATUS = "SUCCESS";
	public static final String WARN_STATUS = "WARN";
	public static final String FAILED_STATUS = "FAILED";
	
	public static final String rSUCCESS = "000";
	public static final String rProducer_Not_Exist = "301";
	public static final String rNo_Type_Error = "302";
	public static final String rNo_Url_Error = "303";
	public static final String rDup_Val_On_Index = "304";
	public static final String rToo_Many_Rows = "305";
	public static final String rNo_Data_Found = "306";
	public static final String rOther_Error = "307";
	
	//map group, media Type
	public static final int GROUP_SIZE = 40;
	public static final String PRODUCER_ID = "ProducerId";
	public static final String XML_STRING = "XmlStr";
	public static final String REQUEST_GROUP_HEADER = "requestGroup";
	public static final String MEDIA_STRING = "MediaStr";
	
	public static final String DB_FACEBOOK = "FACEBOOK";
	public static final String DB_LINKEDIN = "LINKEDIN";
	public static final String DB_TWITTER = "TWITTER";
	public static final String DB_ORGUNIT = "ORGUNIT";
	public static final String DB_PRODURL = "PRODURL";
	
	public static final String IN_FACEBOOK = "FB";
	public static final String IN_LINKEDIN = "LK";
	public static final String IN_TWITTER = "TW";
	public static final String IN_ORGUNIT = "OU";
	public static final String IN_PRODURL = "PU";
}
