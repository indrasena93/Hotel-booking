package com.newyorklife.service;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * This servlet handles requests for service methods being invoked over HTTP.
 */
public class HealthServlet extends HttpServlet {

	private static final String APPLICATION_JSON = "application/json";

	private static final String PATH_HEALTH = "health";

	private static final long serialVersionUID = -7307441976207152860L;
	
	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		if(isHealthEndpoint(req)) {
			sendHealthResponse(resp);
			return;
		}
		
	}

	private boolean isHealthEndpoint(HttpServletRequest req) {
		boolean isHealth = false;
		String path = req.getRequestURI().substring(req.getContextPath().length());
		String[] pathSegments = null;
		if(path!=null) {
			pathSegments = path.split("/");
		}
		// Expected health enpoint url path pattern is /health
		if (pathSegments != null && path.contains(PATH_HEALTH)) {
			isHealth = true;
		}
		return isHealth;
	}
	
	private void sendHealthResponse(HttpServletResponse resp) throws IOException {
		resp.setContentType(APPLICATION_JSON);
		String output = "{\"status\": \"UP\"}";
		PrintWriter out = resp.getWriter();
		out.println(output);
		out.flush();
		out.close();
	}

}
