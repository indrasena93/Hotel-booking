package  com.newyorklife.admin;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericApplicationContext;

import com.newyorklife.utils.WSConstants;
import com.newyorklife.utils.WSThreadCache;

public class WSApplicationContext implements WSConstants{
	private static final Logger log = LoggerFactory.getLogger(WSApplicationContext.class);
	
	private static final String CLASS_NAME = (String)(WSApplicationContext.getCxtMap().get(APPLICATION_NAME) == null ? WSApplicationContext.class.getName() : WSApplicationContext.getCxtMap().get(APPLICATION_NAME));
	
	private static final Object mutex = new Object();
	
	private static final Map<ClassLoader,ApplicationContext> applicationContextsCache = new HashMap<ClassLoader,ApplicationContext>();
	
	private static WSApplicationContext instance;
	
	private static Map<String, Object> cxtMap;
	
	private WSApplicationContext() {
		
	}
	
	public static WSApplicationContext getInstance() {
		if (instance == null) {
			instance = new WSApplicationContext();
		}
		return instance;
	}
	
	public void initWSApplicationContext() {
		log.info("Start Initialize WSApplicationContext ...");
		
		ClassLoader cl = getApplicationClassLoader();
		
		if (cl != null) {
			instance.getApplicationContext(cl);
		}else {
			instance.getApplicationContext();
		}
		
		log.info("Application ClassLoader: {}", getApplicationClassLoader());
	}
	
	public ApplicationContext getApplicationContext() {
		
		return getApplicationContext(null);
	}
	
	public ApplicationContext getApplicationContext(ClassLoader cl) {
		log.info("start ClassLoader in getApplicationContext(ClassLoader cl)={}", cl);
		
		if (cl == null) {
			cl = getApplicationClassLoader();
		}
		
		if (applicationContextsCache.containsKey(cl)) {
			return applicationContextsCache.get(cl);
		}
		
		return initializeContext(cl);
	}
	
	private ApplicationContext initializeContext(ClassLoader cl) {
		log.info("Start initializeContext for {} Spring Beans ...", WSApplicationContext.getCxtMap().get(APPLICATION_NAME));
		
		GenericApplicationContext context = null;
		
		synchronized (mutex) {
			if (applicationContextsCache.containsKey(cl)) {
				return (ApplicationContext) applicationContextsCache.get(cl);
			}
	        
	        try {
				context = new GenericApplicationContext();
				WSThreadCache.getInstance().put(CLASS_NAME, context);
							
				@SuppressWarnings("unchecked")
				List<String> urls = (List<String>)WSApplicationContext.getCxtMap().get(BEANS_URLS);
				
				if (urls != null && !urls.isEmpty()) {
					XmlBeanDefinitionReader xmlReader = new XmlBeanDefinitionReader(context);
									
					String[] resources = (String[]) urls.toArray(new String[urls.size()]);
					xmlReader.loadBeanDefinitions(resources);
					
					context.refresh(); // Refresh so post-processors are invoked
				}
				
	        }catch (Exception e) {
	        	e.printStackTrace();
	        	log.error("Can not initializeContext for Spring Beans, {}", e.getMessage());
	        }finally {
	        	WSThreadCache.getInstance().remove(CLASS_NAME);
	        }
	        
	        applicationContextsCache.put(cl, context);
	        
		}
		
		return context;
	}
	
	public ClassLoader getApplicationClassLoader() {
		return Thread.currentThread().getContextClassLoader();
	}

	public static Map<String, Object> getCxtMap() {
		
		if (cxtMap == null) {
			cxtMap = new ConcurrentHashMap<String, Object>();
		}
		return cxtMap;
	}

}
