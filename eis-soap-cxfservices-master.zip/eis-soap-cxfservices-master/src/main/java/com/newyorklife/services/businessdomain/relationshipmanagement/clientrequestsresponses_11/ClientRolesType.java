package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.schemas.framework.statusmessage_2.StatusMessageType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.ClientRoleType;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClientRolesType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"statusMessage", "clientRole"})
public class ClientRolesType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "StatusMessage")
  protected StatusMessageType statusMessage;
  
  @XmlElement(name = "ClientRole")
  protected List<ClientRoleType> clientRole;
  
  public StatusMessageType getStatusMessage() {
    return this.statusMessage;
  }
  
  public void setStatusMessage(StatusMessageType paramStatusMessageType) {
    this.statusMessage = paramStatusMessageType;
  }
  
  public List<ClientRoleType> getClientRole() {
    if (this.clientRole == null)
      this.clientRole = new ArrayList<ClientRoleType>(); 
    return this.clientRole;
  }
}
