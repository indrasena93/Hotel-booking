package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.schemas.framework.searchbaserequest_2.SearchBaseRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.NameAndBirthDtType;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SearchClientByNameAndDOBRequestType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"clientNameAndDOB"})
public class SearchClientByNameAndDOBRequestType extends SearchBaseRequestType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "ClientNameAndDOB")
  protected List<NameAndBirthDtType> clientNameAndDOB;
  
  public List<NameAndBirthDtType> getClientNameAndDOB() {
    if (this.clientNameAndDOB == null)
      this.clientNameAndDOB = new ArrayList<NameAndBirthDtType>(); 
    return this.clientNameAndDOB;
  }
}
