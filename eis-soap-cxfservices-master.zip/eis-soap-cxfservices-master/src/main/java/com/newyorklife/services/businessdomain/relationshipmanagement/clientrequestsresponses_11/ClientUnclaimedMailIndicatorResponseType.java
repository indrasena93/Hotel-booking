package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.schemas.framework.baseresponse_2.BaseResponseType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.ClientUnclaimedMailIndicatorAndStatus;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClientUnclaimedMailIndicatorResponseType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"clientUnclaimedMailIndicatorAndStatus"})
public class ClientUnclaimedMailIndicatorResponseType extends BaseResponseType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "ClientUnclaimedMailIndicatorAndStatus")
  protected List<ClientUnclaimedMailIndicatorAndStatus> clientUnclaimedMailIndicatorAndStatus;
  
  public List<ClientUnclaimedMailIndicatorAndStatus> getClientUnclaimedMailIndicatorAndStatus() {
    if (this.clientUnclaimedMailIndicatorAndStatus == null)
      this.clientUnclaimedMailIndicatorAndStatus = new ArrayList<ClientUnclaimedMailIndicatorAndStatus>(); 
    return this.clientUnclaimedMailIndicatorAndStatus;
  }
}
