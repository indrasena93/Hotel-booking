package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.ProducerIdAndNameType;
import java.io.Serializable;
import java.util.Calendar;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import org.w3._2001.xmlschema.Adapter3;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProducerIdAndNameAndBirthDateType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"producerAndName", "birthDate"})
public class ProducerIdAndNameAndBirthDateType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "ProducerAndName")
  protected ProducerIdAndNameType producerAndName;
  
  @XmlElement(name = "BirthDate", type = String.class)
  @XmlJavaTypeAdapter(Adapter3.class)
  protected Calendar birthDate;
  
  public ProducerIdAndNameType getProducerAndName() {
    return this.producerAndName;
  }
  
  public void setProducerAndName(ProducerIdAndNameType paramProducerIdAndNameType) {
    this.producerAndName = paramProducerIdAndNameType;
  }
  
  public Calendar getBirthDate() {
    return this.birthDate;
  }
  
  public void setBirthDate(Calendar paramCalendar) {
    this.birthDate = paramCalendar;
  }
}
