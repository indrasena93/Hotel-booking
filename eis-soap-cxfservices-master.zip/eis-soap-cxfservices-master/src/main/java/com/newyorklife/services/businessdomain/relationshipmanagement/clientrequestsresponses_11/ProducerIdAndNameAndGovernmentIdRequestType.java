package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.schemas.framework.searchbaserequest_2.SearchBaseRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.ProducerIdAndNameAndGovernmentIdType;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProducerIdAndNameAndGovernmentIdRequestType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"producerAndNameAndGovernmentId"})
public class ProducerIdAndNameAndGovernmentIdRequestType extends SearchBaseRequestType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "ProducerAndNameAndGovernmentId")
  protected List<ProducerIdAndNameAndGovernmentIdType> producerAndNameAndGovernmentId;
  
  public List<ProducerIdAndNameAndGovernmentIdType> getProducerAndNameAndGovernmentId() {
    if (this.producerAndNameAndGovernmentId == null)
      this.producerAndNameAndGovernmentId = new ArrayList<ProducerIdAndNameAndGovernmentIdType>(); 
    return this.producerAndNameAndGovernmentId;
  }
}
