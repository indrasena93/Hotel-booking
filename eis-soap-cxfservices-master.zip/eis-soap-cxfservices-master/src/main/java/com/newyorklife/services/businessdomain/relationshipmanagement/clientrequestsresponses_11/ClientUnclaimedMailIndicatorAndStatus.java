package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.schemas.framework.statusmessage_2.StatusMessageType;
import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClientUnclaimedMailIndicatorAndStatus", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"statusMessage", "clientId", "unclaimedMailIn"})
public class ClientUnclaimedMailIndicatorAndStatus implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "StatusMessage")
  protected StatusMessageType statusMessage;
  
  @XmlElement(name = "ClientId")
  protected String clientId;
  
  @XmlElement(name = "UnclaimedMailIn")
  protected Boolean unclaimedMailIn;
  
  public StatusMessageType getStatusMessage() {
    return this.statusMessage;
  }
  
  public void setStatusMessage(StatusMessageType paramStatusMessageType) {
    this.statusMessage = paramStatusMessageType;
  }
  
  public String getClientId() {
    return this.clientId;
  }
  
  public void setClientId(String paramString) {
    this.clientId = paramString;
  }
  
  public Boolean isUnclaimedMailIn() {
    return this.unclaimedMailIn;
  }
  
  public void setUnclaimedMailIn(Boolean paramBoolean) {
    this.unclaimedMailIn = paramBoolean;
  }
}
