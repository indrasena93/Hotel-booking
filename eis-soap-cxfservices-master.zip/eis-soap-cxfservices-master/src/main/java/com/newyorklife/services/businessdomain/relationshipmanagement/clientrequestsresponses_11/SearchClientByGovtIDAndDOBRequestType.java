package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.schemas.framework.searchbaserequest_2.SearchBaseRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.GovtIDAndDOBType;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SearchClientByGovtIDAndDOBRequestType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"clientGovtIDAndDOB"})
public class SearchClientByGovtIDAndDOBRequestType extends SearchBaseRequestType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "ClientGovtIDAndDOB")
  protected List<GovtIDAndDOBType> clientGovtIDAndDOB;
  
  public List<GovtIDAndDOBType> getClientGovtIDAndDOB() {
    if (this.clientGovtIDAndDOB == null)
      this.clientGovtIDAndDOB = new ArrayList<GovtIDAndDOBType>(); 
    return this.clientGovtIDAndDOB;
  }
}
