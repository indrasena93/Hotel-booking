package com.newyorklife.services.businessdomain.relationshipmanagement.producerassignment;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.xml.bind.annotation.XmlSeeAlso;
import com.newyorklife.services.businessdomain.relationshipmanagement.producerrelationshiprequestsresponses_1.AssignProducerByClientIDRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.producerrelationshiprequestsresponses_1.AssignProducerByClientIDResponseType;
import com.newyorklife.services.businessdomain.relationshipmanagement.producerrelationshiprequestsresponses_1.AssignProducerByClientProfileRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.producerrelationshiprequestsresponses_1.AssignProducerByClientProfileResponseType;

@WebService(name = "ProducerAssignmentPortType", targetNamespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/producerassignment")
@SOAPBinding(parameterStyle = SOAPBinding.ParameterStyle.BARE)

public interface ProducerAssignmentPortType {


    /**
     * Returns a client id if a lead/prospect is a NYL client.
     * 
     * @param assignProducerByClientIDRequest
     * @return
     *     returns com.newyorklife.services.businessdomain.relationshipmanagement.producerrelationshiprequestsresponses_1.AssignProducerByClientIDResponseType
     * @throws SystemException
     * @throws FatalException
     * @throws BusinessException
     */
    @WebMethod(action = "http://newyorklife.com/services/businessdomain/relationshipmanagement/producerassignment/assignProducerByClientID")
    @WebResult(name = "AssignProducerByClientIDResponse", targetNamespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/producerassignment", partName = "AssignProducerByClientIDResponse")
    public AssignProducerByClientIDResponseType assignProducerByClientID(
        @WebParam(name = "AssignProducerByClientIDRequest", targetNamespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/producerassignment", partName = "AssignProducerByClientIDRequest")
        AssignProducerByClientIDRequestType assignProducerByClientIDRequest)
        throws BusinessException, FatalException, SystemException
    ;

    /**
     * Returns a client id if a lead/prospect is a NYL client and a producer id for the assigned agent.
     * 
     * @param assignProducerByClientProfileRequest
     * @return
     *     returns com.newyorklife.services.businessdomain.relationshipmanagement.producerrelationshiprequestsresponses_1.AssignProducerByClientProfileResponseType
     * @throws SystemException
     * @throws FatalException
     * @throws BusinessException
     */
    @WebMethod(action = "http://newyorklife.com/services/businessdomain/relationshipmanagement/producerassignment/assignProducerByClientProfile")
    @WebResult(name = "AssignProducerByClientProfileResponse", targetNamespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/producerassignment", partName = "AssignProducerByClientProfileResponse")
    public AssignProducerByClientProfileResponseType assignProducerByClientProfile(
        @WebParam(name = "AssignProducerByClientProfileRequest", targetNamespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/producerassignment", partName = "AssignProducerByClientProfileRequest")
        AssignProducerByClientProfileRequestType assignProducerByClientProfileRequest)
        throws BusinessException, FatalException, SystemException
    ;

}
