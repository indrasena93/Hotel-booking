package com.newyorklife.services.businessdomain.relationshipmanagement.producerrelationshiprequestsresponses_1;

import com.newyorklife.services.businessdomain.relationshipmanagement.producerrelationshiprequestsresponses_1.AssignProducerByClientIDRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.producerrelationshiprequestsresponses_1.AssignProducerByClientIDResponseType;
import com.newyorklife.services.businessdomain.relationshipmanagement.producerrelationshiprequestsresponses_1.AssignProducerByClientProfileRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.producerrelationshiprequestsresponses_1.AssignProducerByClientProfileResponseType;
import javax.xml.bind.annotation.XmlRegistry;

@XmlRegistry
public class ObjectFactory {
  public AssignProducerByClientProfileResponseType.AssignmentIdsAndStatusType createAssignProducerByClientProfileResponseTypeAssignmentIdsAndStatusType() {
    return new AssignProducerByClientProfileResponseType.AssignmentIdsAndStatusType();
  }
  
  public AssignProducerByClientProfileRequestType createAssignProducerByClientProfileRequestType() {
    return new AssignProducerByClientProfileRequestType();
  }
  
  public AssignProducerByClientProfileResponseType createAssignProducerByClientProfileResponseType() {
    return new AssignProducerByClientProfileResponseType();
  }
  
  public AssignProducerByClientProfileRequestType.ClientProfile createAssignProducerByClientProfileRequestTypeClientProfile() {
    return new AssignProducerByClientProfileRequestType.ClientProfile();
  }
  
  public AssignProducerByClientIDResponseType createAssignProducerByClientIDResponseType() {
    return new AssignProducerByClientIDResponseType();
  }
  
  public AssignProducerByClientIDResponseType.ProducerProfileAndStatusType createAssignProducerByClientIDResponseTypeProducerProfileAndStatusType() {
    return new AssignProducerByClientIDResponseType.ProducerProfileAndStatusType();
  }
  
  public AssignProducerByClientIDRequestType createAssignProducerByClientIDRequestType() {
    return new AssignProducerByClientIDRequestType();
  }
}
