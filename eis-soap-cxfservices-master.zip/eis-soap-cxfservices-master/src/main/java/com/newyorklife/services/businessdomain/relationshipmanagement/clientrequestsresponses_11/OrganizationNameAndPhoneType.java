package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.schemas.cim.common.name_4.NameType;
import com.newyorklife.schemas.cim.contactinformation.phonenumber_5.PhoneNumberType;
import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OrganizationNameAndPhoneType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"name", "phoneNumber"})
public class OrganizationNameAndPhoneType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "Name")
  protected NameType name;
  
  @XmlElement(name = "PhoneNumber")
  protected PhoneNumberType phoneNumber;
  
  public NameType getName() {
    return this.name;
  }
  
  public void setName(NameType paramNameType) {
    this.name = paramNameType;
  }
  
  public PhoneNumberType getPhoneNumber() {
    return this.phoneNumber;
  }
  
  public void setPhoneNumber(PhoneNumberType paramPhoneNumberType) {
    this.phoneNumber = paramPhoneNumberType;
  }
}
