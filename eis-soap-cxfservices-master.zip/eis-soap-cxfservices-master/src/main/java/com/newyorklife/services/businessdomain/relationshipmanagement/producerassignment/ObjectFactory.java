package com.newyorklife.services.businessdomain.relationshipmanagement.producerassignment;

import com.newyorklife.services.businessdomain.relationshipmanagement.producerrelationshiprequestsresponses_1.AssignProducerByClientIDRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.producerrelationshiprequestsresponses_1.AssignProducerByClientIDResponseType;
import com.newyorklife.services.businessdomain.relationshipmanagement.producerrelationshiprequestsresponses_1.AssignProducerByClientProfileRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.producerrelationshiprequestsresponses_1.AssignProducerByClientProfileResponseType;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

@XmlRegistry
public class ObjectFactory {
  private static final QName _AssignProducerByClientIDRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/producerassignment", "AssignProducerByClientIDRequest");
  
  private static final QName _AssignProducerByClientIDResponse_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/producerassignment", "AssignProducerByClientIDResponse");
  
  private static final QName _AssignProducerByClientProfileResponse_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/producerassignment", "AssignProducerByClientProfileResponse");
  
  private static final QName _AssignProducerByClientProfileRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/producerassignment", "AssignProducerByClientProfileRequest");
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/producerassignment", name = "AssignProducerByClientIDRequest")
  public JAXBElement<AssignProducerByClientIDRequestType> createAssignProducerByClientIDRequest(AssignProducerByClientIDRequestType paramAssignProducerByClientIDRequestType) {
    return new JAXBElement<AssignProducerByClientIDRequestType>(_AssignProducerByClientIDRequest_QNAME, AssignProducerByClientIDRequestType.class, null, paramAssignProducerByClientIDRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/producerassignment", name = "AssignProducerByClientIDResponse")
  public JAXBElement<AssignProducerByClientIDResponseType> createAssignProducerByClientIDResponse(AssignProducerByClientIDResponseType paramAssignProducerByClientIDResponseType) {
    return new JAXBElement<AssignProducerByClientIDResponseType>(_AssignProducerByClientIDResponse_QNAME, AssignProducerByClientIDResponseType.class, null, paramAssignProducerByClientIDResponseType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/producerassignment", name = "AssignProducerByClientProfileResponse")
  public JAXBElement<AssignProducerByClientProfileResponseType> createAssignProducerByClientProfileResponse(AssignProducerByClientProfileResponseType paramAssignProducerByClientProfileResponseType) {
    return new JAXBElement<AssignProducerByClientProfileResponseType>(_AssignProducerByClientProfileResponse_QNAME, AssignProducerByClientProfileResponseType.class, null, paramAssignProducerByClientProfileResponseType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/producerassignment", name = "AssignProducerByClientProfileRequest")
  public JAXBElement<AssignProducerByClientProfileRequestType> createAssignProducerByClientProfileRequest(AssignProducerByClientProfileRequestType paramAssignProducerByClientProfileRequestType) {
    return new JAXBElement<AssignProducerByClientProfileRequestType>(_AssignProducerByClientProfileRequest_QNAME, AssignProducerByClientProfileRequestType.class, null, paramAssignProducerByClientProfileRequestType);
  }
}
