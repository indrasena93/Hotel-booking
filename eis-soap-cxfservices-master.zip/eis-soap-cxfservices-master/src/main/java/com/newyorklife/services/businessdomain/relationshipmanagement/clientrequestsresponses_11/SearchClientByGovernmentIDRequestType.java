package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.schemas.cim.common.governmenttaxtype_3.GovernmentTaxType;
import com.newyorklife.schemas.framework.searchbaserequest_2.SearchBaseRequestType;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SearchClientByGovernmentIDRequestType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"governmentId"})
public class SearchClientByGovernmentIDRequestType extends SearchBaseRequestType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "GovernmentId")
  protected List<GovernmentTaxType> governmentId;
  
  public List<GovernmentTaxType> getGovernmentId() {
    if (this.governmentId == null)
      this.governmentId = new ArrayList<GovernmentTaxType>(); 
    return this.governmentId;
  }
}
