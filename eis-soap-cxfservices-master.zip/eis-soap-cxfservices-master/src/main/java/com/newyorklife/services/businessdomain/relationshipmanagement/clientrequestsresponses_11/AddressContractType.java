package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.schemas.cim.common.codetype_1.CodeType;
import com.newyorklife.schemas.cim.contactinformation.postaladdress_6.PostalAddressType;
import com.newyorklife.schemas.cim.financialcontract.contract_5.ContractType;
import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AddressContractType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"contract", "clientRoleCd", "postalAddress"})
public class AddressContractType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "Contract")
  protected ContractType contract;
  
  @XmlElement(name = "ClientRoleCd")
  protected CodeType clientRoleCd;
  
  @XmlElement(name = "PostalAddress")
  protected PostalAddressType postalAddress;
  
  public ContractType getContract() {
    return this.contract;
  }
  
  public void setContract(ContractType paramContractType) {
    this.contract = paramContractType;
  }
  
  public CodeType getClientRoleCd() {
    return this.clientRoleCd;
  }
  
  public void setClientRoleCd(CodeType paramCodeType) {
    this.clientRoleCd = paramCodeType;
  }
  
  public PostalAddressType getPostalAddress() {
    return this.postalAddress;
  }
  
  public void setPostalAddress(PostalAddressType paramPostalAddressType) {
    this.postalAddress = paramPostalAddressType;
  }
}
