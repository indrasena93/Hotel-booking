package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.schemas.cim.common.governmenttaxtype_3.GovernmentTaxType;
import com.newyorklife.schemas.cim.common.name_4.NameType;
import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GovtIDAndOrganizationNameType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"governmentId", "name"})
public class GovtIDAndOrganizationNameType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "GovernmentId")
  protected GovernmentTaxType governmentId;
  
  @XmlElement(name = "Name")
  protected NameType name;
  
  public GovernmentTaxType getGovernmentId() {
    return this.governmentId;
  }
  
  public void setGovernmentId(GovernmentTaxType paramGovernmentTaxType) {
    this.governmentId = paramGovernmentTaxType;
  }
  
  public NameType getName() {
    return this.name;
  }
  
  public void setName(NameType paramNameType) {
    this.name = paramNameType;
  }
}
