package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.schemas.framework.searchbaserequest_2.SearchBaseRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.OrganizationNameAndZipCdType;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SearchClientByOrganizationNameAndZipRequestType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"clientOrganizationNameAndZip"})
public class SearchClientByOrganizationNameAndZipRequestType extends SearchBaseRequestType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "ClientOrganizationNameAndZip")
  protected List<OrganizationNameAndZipCdType> clientOrganizationNameAndZip;
  
  public List<OrganizationNameAndZipCdType> getClientOrganizationNameAndZip() {
    if (this.clientOrganizationNameAndZip == null)
      this.clientOrganizationNameAndZip = new ArrayList<OrganizationNameAndZipCdType>(); 
    return this.clientOrganizationNameAndZip;
  }
}
