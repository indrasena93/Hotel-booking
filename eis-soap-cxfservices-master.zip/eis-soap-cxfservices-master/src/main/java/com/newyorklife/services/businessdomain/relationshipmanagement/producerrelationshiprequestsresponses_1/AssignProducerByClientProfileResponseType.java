package com.newyorklife.services.businessdomain.relationshipmanagement.producerrelationshiprequestsresponses_1;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.newyorklife.schemas.framework.baseresponse_2.BaseResponseType;
import com.newyorklife.schemas.framework.statusmessage_2.StatusMessageType;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AssignProducerByClientProfileResponseType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/producerrelationshiprequestsresponses", propOrder = {"assignmentIdsAndStatusType"})
public class AssignProducerByClientProfileResponseType extends BaseResponseType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "AssignmentIdsAndStatusType")
  protected List<AssignProducerByClientProfileResponseType.AssignmentIdsAndStatusType> assignmentIdsAndStatusType;
  
  public List<AssignProducerByClientProfileResponseType.AssignmentIdsAndStatusType> getAssignmentIdsAndStatusType() {
    if (this.assignmentIdsAndStatusType == null)
      this.assignmentIdsAndStatusType = new ArrayList<AssignProducerByClientProfileResponseType.AssignmentIdsAndStatusType>(); 
    return this.assignmentIdsAndStatusType;
  }
  /**
   * <p>Java class for anonymous complex type.
   * 
   * <p>The following schema fragment specifies the expected content contained within this class.
   * 
   * <pre>
   * &lt;complexType>
   *   &lt;complexContent>
   *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
   *       &lt;sequence>
   *         &lt;element name="StatusMessage" type="{http://newyorklife.com/schemas/framework/statusmessage}StatusMessageType" minOccurs="0"/>
   *         &lt;element name="ClientId" type="{http://newyorklife.com/schemas/cim/common/id}IDType" minOccurs="0"/>
   *         &lt;element name="ProducerId" type="{http://newyorklife.com/schemas/cim/common/id}IDType" minOccurs="0"/>
   *       &lt;/sequence>
   *     &lt;/restriction>
   *   &lt;/complexContent>
   * &lt;/complexType>
   * </pre>
   * 
   * 
   */
  @XmlAccessorType(XmlAccessType.FIELD)
  @XmlType(name = "", propOrder = {
      "statusMessage",
      "clientId",
      "producerId"
  })
  public static class AssignmentIdsAndStatusType
      implements Serializable
  {

      private final static long serialVersionUID = -6026937020915831338L;
      @XmlElement(name = "StatusMessage")
      protected StatusMessageType statusMessage;
      @XmlElement(name = "ClientId")
      protected String clientId;
      @XmlElement(name = "ProducerId")
      protected String producerId;

      /**
       * Gets the value of the statusMessage property.
       * 
       * @return
       *     possible object is
       *     {@link StatusMessageType }
       *     
       */
      public StatusMessageType getStatusMessage() {
          return statusMessage;
      }

      /**
       * Sets the value of the statusMessage property.
       * 
       * @param value
       *     allowed object is
       *     {@link StatusMessageType }
       *     
       */
      public void setStatusMessage(StatusMessageType value) {
          this.statusMessage = value;
      }

      /**
       * Gets the value of the clientId property.
       * 
       * @return
       *     possible object is
       *     {@link String }
       *     
       */
      public String getClientId() {
          return clientId;
      }

      /**
       * Sets the value of the clientId property.
       * 
       * @param value
       *     allowed object is
       *     {@link String }
       *     
       */
      public void setClientId(String value) {
          this.clientId = value;
      }

      /**
       * Gets the value of the producerId property.
       * 
       * @return
       *     possible object is
       *     {@link String }
       *     
       */
      public String getProducerId() {
          return producerId;
      }

      /**
       * Sets the value of the producerId property.
       * 
       * @param value
       *     allowed object is
       *     {@link String }
       *     
       */
      public void setProducerId(String value) {
          this.producerId = value;
      }

  }

}

