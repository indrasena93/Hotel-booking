package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.schemas.cim.common.codetype_1.CodeType;
import com.newyorklife.schemas.cim.common.name_4.NameType;
import com.newyorklife.schemas.cim.financialcontract.contract_5.ContractType;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClientRoleType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"clientId", "name", "contract", "clientRoleCd"})
public class ClientRoleType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "ClientId")
  protected String clientId;
  
  @XmlElement(name = "Name")
  protected NameType name;
  
  @XmlElement(name = "Contract")
  protected ContractType contract;
  
  @XmlElement(name = "ClientRoleCd")
  protected List<CodeType> clientRoleCd;
  
  public String getClientId() {
    return this.clientId;
  }
  
  public void setClientId(String paramString) {
    this.clientId = paramString;
  }
  
  public NameType getName() {
    return this.name;
  }
  
  public void setName(NameType paramNameType) {
    this.name = paramNameType;
  }
  
  public ContractType getContract() {
    return this.contract;
  }
  
  public void setContract(ContractType paramContractType) {
    this.contract = paramContractType;
  }
  
  public List<CodeType> getClientRoleCd() {
    if (this.clientRoleCd == null)
      this.clientRoleCd = new ArrayList<CodeType>(); 
    return this.clientRoleCd;
  }
}
