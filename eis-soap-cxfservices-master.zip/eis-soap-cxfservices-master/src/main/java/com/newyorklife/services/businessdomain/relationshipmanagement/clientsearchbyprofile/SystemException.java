package com.newyorklife.services.businessdomain.relationshipmanagement.clientsearchbyprofile;

import com.newyorklife.schemas.framework.systemexception_2.SystemExceptionType;
import javax.xml.ws.WebFault;

@WebFault(name = "SystemException", targetNamespace = "http://newyorklife.com/schemas/framework/systemexception")
public class SystemException extends Exception {
  private SystemExceptionType faultInfo;
  
  public SystemException(String paramString, SystemExceptionType paramSystemExceptionType) {
    super(paramString);
    this.faultInfo = paramSystemExceptionType;
  }
  
  public SystemException(String paramString, SystemExceptionType paramSystemExceptionType, Throwable paramThrowable) {
    super(paramString, paramThrowable);
    this.faultInfo = paramSystemExceptionType;
  }
  
  public SystemExceptionType getFaultInfo() {
    return this.faultInfo;
  }
}
