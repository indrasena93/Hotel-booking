package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.schemas.cim.common.name_4.NameType;
import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EmailAddressAndNameType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"emailAd", "name"})
public class EmailAddressAndNameType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "EmailAd")
  protected String emailAd;
  
  @XmlElement(name = "Name")
  protected NameType name;
  
  public String getEmailAd() {
    return this.emailAd;
  }
  
  public void setEmailAd(String paramString) {
    this.emailAd = paramString;
  }
  
  public NameType getName() {
    return this.name;
  }
  
  public void setName(NameType paramNameType) {
    this.name = paramNameType;
  }
}
