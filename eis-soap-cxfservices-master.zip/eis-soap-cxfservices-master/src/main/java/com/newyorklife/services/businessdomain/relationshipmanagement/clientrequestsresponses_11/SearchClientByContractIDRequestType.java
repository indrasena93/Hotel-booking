package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.schemas.cim.financialcontract.contract_5.ContractType;
import com.newyorklife.schemas.framework.searchbaserequest_2.SearchBaseRequestType;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SearchClientByContractIDRequestType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"contract"})
public class SearchClientByContractIDRequestType extends SearchBaseRequestType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "Contract")
  protected List<ContractType> contract;
  
  public List<ContractType> getContract() {
    if (this.contract == null)
      this.contract = new ArrayList<ContractType>(); 
    return this.contract;
  }
}
