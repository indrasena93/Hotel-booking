package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProducerIdAndGovernmentIdType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"producerId", "governmentId"})
public class ProducerIdAndGovernmentIdType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "ProducerId")
  protected String producerId;
  
  @XmlElement(name = "GovernmentId")
  protected String governmentId;
  
  public String getProducerId() {
    return this.producerId;
  }
  
  public void setProducerId(String paramString) {
    this.producerId = paramString;
  }
  
  public String getGovernmentId() {
    return this.governmentId;
  }
  
  public void setGovernmentId(String paramString) {
    this.governmentId = paramString;
  }
}
