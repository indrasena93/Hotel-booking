package com.newyorklife.services.businessdomain.relationshipmanagement.clientsearchbyprofile;

import com.newyorklife.schemas.framework.fatalexception_2.FatalExceptionType;
import javax.xml.ws.WebFault;

@WebFault(name = "FatalException", targetNamespace = "http://newyorklife.com/schemas/framework/fatalexception")
public class FatalException extends Exception {
  private FatalExceptionType faultInfo;
  
  public FatalException(String paramString, FatalExceptionType paramFatalExceptionType) {
    super(paramString);
    this.faultInfo = paramFatalExceptionType;
  }
  
  public FatalException(String paramString, FatalExceptionType paramFatalExceptionType, Throwable paramThrowable) {
    super(paramString, paramThrowable);
    this.faultInfo = paramFatalExceptionType;
  }
  
  public FatalExceptionType getFaultInfo() {
    return this.faultInfo;
  }
}
