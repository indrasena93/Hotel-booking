package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.schemas.framework.searchbaserequest_2.SearchBaseRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.EmailAddressAndDOBType;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EmailAddressAndDOBRequestType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"emailAddressAndDOB"})
public class EmailAddressAndDOBRequestType extends SearchBaseRequestType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "EmailAddressAndDOB")
  protected List<EmailAddressAndDOBType> emailAddressAndDOB;
  
  public List<EmailAddressAndDOBType> getEmailAddressAndDOB() {
    if (this.emailAddressAndDOB == null)
      this.emailAddressAndDOB = new ArrayList<EmailAddressAndDOBType>(); 
    return this.emailAddressAndDOB;
  }
}
