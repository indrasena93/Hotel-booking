package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.schemas.cim.common.codetype_1.CodeType;
import com.newyorklife.schemas.cim.common.name_4.NameType;
import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "NameAndStateCdType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"name", "stateCd"})
public class NameAndStateCdType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "Name")
  protected NameType name;
  
  @XmlElement(name = "StateCd")
  protected CodeType stateCd;
  
  public NameType getName() {
    return this.name;
  }
  
  public void setName(NameType paramNameType) {
    this.name = paramNameType;
  }
  
  public CodeType getStateCd() {
    return this.stateCd;
  }
  
  public void setStateCd(CodeType paramCodeType) {
    this.stateCd = paramCodeType;
  }
}
