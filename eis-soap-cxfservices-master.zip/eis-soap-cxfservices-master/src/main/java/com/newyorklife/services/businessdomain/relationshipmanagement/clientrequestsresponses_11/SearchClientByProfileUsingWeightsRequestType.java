package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import com.newyorklife.schemas.cim.common.codetype_1.CodeType;
import com.newyorklife.schemas.framework.baserequest_2.BaseRequestType;
import org.w3._2001.xmlschema.Adapter3;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SearchClientByProfileUsingWeightsRequestType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"clientProfile"})
public class SearchClientByProfileUsingWeightsRequestType extends BaseRequestType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "ClientProfile", required = true)
  protected List<SearchClientByProfileUsingWeightsRequestType.ClientProfile> clientProfile;
  
  public List<SearchClientByProfileUsingWeightsRequestType.ClientProfile> getClientProfile() {
    if (this.clientProfile == null)
      this.clientProfile = new ArrayList<SearchClientByProfileUsingWeightsRequestType.ClientProfile>(); 
    return this.clientProfile;
  }
  /**
   * <p>Java class for anonymous complex type.
   * 
   * <p>The following schema fragment specifies the expected content contained within this class.
   * 
   * <pre>
   * &lt;complexType>
   *   &lt;complexContent>
   *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
   *       &lt;sequence>
   *         &lt;element name="BirthDt" type="{http://newyorklife.com/schemas/cim/common/datetype}DateType" minOccurs="0"/>
   *         &lt;element name="CityAd" type="{http://newyorklife.com/schemas/cim/common/text}TextType" minOccurs="0"/>
   *         &lt;element name="FirstNm" type="{http://newyorklife.com/schemas/cim/common/text}TextType" minOccurs="0"/>
   *         &lt;element name="GovernmentTaxId" type="{http://newyorklife.com/schemas/cim/common/text}TextType" minOccurs="0"/>
   *         &lt;element name="LastNm" type="{http://newyorklife.com/schemas/cim/common/text}TextType" minOccurs="0"/>
   *         &lt;element name="Line1Ad" type="{http://newyorklife.com/schemas/cim/common/text}TextType" minOccurs="0"/>
   *         &lt;element name="PostalCd" type="{http://newyorklife.com/schemas/cim/common/text}TextType" minOccurs="0"/>
   *         &lt;element name="StateCd" type="{http://newyorklife.com/schemas/cim/common/codetype/}CodeType" minOccurs="0"/>
   *       &lt;/sequence>
   *     &lt;/restriction>
   *   &lt;/complexContent>
   * &lt;/complexType>
   * </pre>
   * 
   * 
   */
  @XmlAccessorType(XmlAccessType.FIELD)
  @XmlType(name = "", propOrder = {
      "birthDt",
      "cityAd",
      "firstNm",
      "governmentTaxId",
      "lastNm",
      "line1Ad",
      "postalCd",
      "stateCd"
  })
  public static class ClientProfile
      implements Serializable
  {

      private final static long serialVersionUID = -6026937020915831338L;
      @XmlElement(name = "BirthDt", type = String.class)
      @XmlJavaTypeAdapter(Adapter3 .class)
      protected Calendar birthDt;
      @XmlElement(name = "CityAd")
      protected String cityAd;
      @XmlElement(name = "FirstNm")
      protected String firstNm;
      @XmlElement(name = "GovernmentTaxId")
      protected String governmentTaxId;
      @XmlElement(name = "LastNm")
      protected String lastNm;
      @XmlElement(name = "Line1Ad")
      protected String line1Ad;
      @XmlElement(name = "PostalCd")
      protected String postalCd;
      @XmlElement(name = "StateCd")
      protected CodeType stateCd;

      /**
       * Gets the value of the birthDt property.
       * 
       * @return
       *     possible object is
       *     {@link String }
       *     
       */
      public Calendar getBirthDt() {
          return birthDt;
      }

      /**
       * Sets the value of the birthDt property.
       * 
       * @param value
       *     allowed object is
       *     {@link String }
       *     
       */
      public void setBirthDt(Calendar value) {
          this.birthDt = value;
      }

      /**
       * Gets the value of the cityAd property.
       * 
       * @return
       *     possible object is
       *     {@link String }
       *     
       */
      public String getCityAd() {
          return cityAd;
      }

      /**
       * Sets the value of the cityAd property.
       * 
       * @param value
       *     allowed object is
       *     {@link String }
       *     
       */
      public void setCityAd(String value) {
          this.cityAd = value;
      }

      /**
       * Gets the value of the firstNm property.
       * 
       * @return
       *     possible object is
       *     {@link String }
       *     
       */
      public String getFirstNm() {
          return firstNm;
      }

      /**
       * Sets the value of the firstNm property.
       * 
       * @param value
       *     allowed object is
       *     {@link String }
       *     
       */
      public void setFirstNm(String value) {
          this.firstNm = value;
      }

      /**
       * Gets the value of the governmentTaxId property.
       * 
       * @return
       *     possible object is
       *     {@link String }
       *     
       */
      public String getGovernmentTaxId() {
          return governmentTaxId;
      }

      /**
       * Sets the value of the governmentTaxId property.
       * 
       * @param value
       *     allowed object is
       *     {@link String }
       *     
       */
      public void setGovernmentTaxId(String value) {
          this.governmentTaxId = value;
      }

      /**
       * Gets the value of the lastNm property.
       * 
       * @return
       *     possible object is
       *     {@link String }
       *     
       */
      public String getLastNm() {
          return lastNm;
      }

      /**
       * Sets the value of the lastNm property.
       * 
       * @param value
       *     allowed object is
       *     {@link String }
       *     
       */
      public void setLastNm(String value) {
          this.lastNm = value;
      }

      /**
       * Gets the value of the line1Ad property.
       * 
       * @return
       *     possible object is
       *     {@link String }
       *     
       */
      public String getLine1Ad() {
          return line1Ad;
      }

      /**
       * Sets the value of the line1Ad property.
       * 
       * @param value
       *     allowed object is
       *     {@link String }
       *     
       */
      public void setLine1Ad(String value) {
          this.line1Ad = value;
      }

      /**
       * Gets the value of the postalCd property.
       * 
       * @return
       *     possible object is
       *     {@link String }
       *     
       */
      public String getPostalCd() {
          return postalCd;
      }

      /**
       * Sets the value of the postalCd property.
       * 
       * @param value
       *     allowed object is
       *     {@link String }
       *     
       */
      public void setPostalCd(String value) {
          this.postalCd = value;
      }

      /**
       * Gets the value of the stateCd property.
       * 
       * @return
       *     possible object is
       *     {@link CodeType }
       *     
       */
      public CodeType getStateCd() {
          return stateCd;
      }

      /**
       * Sets the value of the stateCd property.
       * 
       * @param value
       *     allowed object is
       *     {@link CodeType }
       *     
       */
      public void setStateCd(CodeType value) {
          this.stateCd = value;
      }

  }

}

