package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.schemas.cim.client.clientprofile.clientprofile_10.ClientProfileType;
import com.newyorklife.schemas.framework.statusmessage_2.StatusMessageType;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClientProfileStatusType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"statusMessage", "clientProfile"})
public class ClientProfileStatusType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "StatusMessage")
  protected StatusMessageType statusMessage;
  
  @XmlElement(name = "ClientProfile")
  protected List<ClientProfileType> clientProfile;
  
  public StatusMessageType getStatusMessage() {
    return this.statusMessage;
  }
  
  public void setStatusMessage(StatusMessageType paramStatusMessageType) {
    this.statusMessage = paramStatusMessageType;
  }
  
  public List<ClientProfileType> getClientProfile() {
    if (this.clientProfile == null)
      this.clientProfile = new ArrayList<ClientProfileType>(); 
    return this.clientProfile;
  }
}
