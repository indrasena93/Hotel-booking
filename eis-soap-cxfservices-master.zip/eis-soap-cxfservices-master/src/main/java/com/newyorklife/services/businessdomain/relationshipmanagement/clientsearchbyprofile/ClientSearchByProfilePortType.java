package com.newyorklife.services.businessdomain.relationshipmanagement.clientsearchbyprofile;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.xml.bind.annotation.XmlSeeAlso;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.ClientProfileResponseType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.SearchClientByProfileUsingWeightsRequestType;

@WebService(name = "ClientSearchByProfilePortType", targetNamespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientsearchbyprofile")
@SOAPBinding(parameterStyle = SOAPBinding.ParameterStyle.BARE)

public interface ClientSearchByProfilePortType {

	/**
	 * Returns a client id if a lead/prospect is a NYL client.
	 * 
	 * @param searchClientByProfileUsingWeightsRequest
	 * @return returns
	 *         com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.ClientProfileResponseType
	 * @throws SystemException
	 * @throws FatalException
	 * @throws BusinessException
	 */
	@WebMethod(action = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientsearchbyprofile/searchClientByProfileUsingWeights")
	@WebResult(name = "SearchClientByProfileUsingWeightsResponse", targetNamespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientsearchbyprofile", partName = "SearchClientByProfileUsingWeightsResponse")
	public ClientProfileResponseType searchClientByProfileUsingWeights(
			@WebParam(name = "SearchClientByProfileUsingWeightsRequest", targetNamespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientsearchbyprofile", partName = "SearchClientByProfileUsingWeightsRequest") SearchClientByProfileUsingWeightsRequestType searchClientByProfileUsingWeightsRequest)
			throws BusinessException, FatalException, SystemException;

}
