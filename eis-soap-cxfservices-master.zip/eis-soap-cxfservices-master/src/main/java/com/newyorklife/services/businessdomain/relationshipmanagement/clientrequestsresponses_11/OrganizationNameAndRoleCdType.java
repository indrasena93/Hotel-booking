package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.schemas.cim.common.codetype_1.CodeType;
import com.newyorklife.schemas.cim.common.name_4.NameType;
import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OrganizationNameAndRoleCdType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"name", "roleCd"})
public class OrganizationNameAndRoleCdType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "Name")
  protected NameType name;
  
  @XmlElement(name = "RoleCd")
  protected CodeType roleCd;
  
  public NameType getName() {
    return this.name;
  }
  
  public void setName(NameType paramNameType) {
    this.name = paramNameType;
  }
  
  public CodeType getRoleCd() {
    return this.roleCd;
  }
  
  public void setRoleCd(CodeType paramCodeType) {
    this.roleCd = paramCodeType;
  }
}
