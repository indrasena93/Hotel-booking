package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.schemas.framework.baseresponse_2.BaseResponseType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.ClientUnclaimedMailAndStatus;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClientUnclaimedMailResponseType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"clientUnclaimedMailAndStatus"})
public class ClientUnclaimedMailResponseType extends BaseResponseType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "ClientUnclaimedMailAndStatus")
  protected List<ClientUnclaimedMailAndStatus> clientUnclaimedMailAndStatus;
  
  public List<ClientUnclaimedMailAndStatus> getClientUnclaimedMailAndStatus() {
    if (this.clientUnclaimedMailAndStatus == null)
      this.clientUnclaimedMailAndStatus = new ArrayList<ClientUnclaimedMailAndStatus>(); 
    return this.clientUnclaimedMailAndStatus;
  }
}
