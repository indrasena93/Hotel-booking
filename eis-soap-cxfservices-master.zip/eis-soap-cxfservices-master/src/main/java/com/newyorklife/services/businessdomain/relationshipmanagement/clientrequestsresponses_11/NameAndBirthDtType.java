package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.schemas.cim.common.name_4.NameType;
import java.io.Serializable;
import java.util.Calendar;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import org.w3._2001.xmlschema.Adapter3;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "NameAndBirthDtType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"name", "birthDt"})
public class NameAndBirthDtType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "Name")
  protected NameType name;
  
  @XmlElement(name = "BirthDt", type = String.class)
  @XmlJavaTypeAdapter(Adapter3.class)
  protected Calendar birthDt;
  
  public NameType getName() {
    return this.name;
  }
  
  public void setName(NameType paramNameType) {
    this.name = paramNameType;
  }
  
  public Calendar getBirthDt() {
    return this.birthDt;
  }
  
  public void setBirthDt(Calendar paramCalendar) {
    this.birthDt = paramCalendar;
  }
}
