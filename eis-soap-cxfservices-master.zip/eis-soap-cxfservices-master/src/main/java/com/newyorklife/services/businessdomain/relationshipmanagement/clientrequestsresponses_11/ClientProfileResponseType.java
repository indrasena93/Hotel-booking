package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.schemas.framework.searchbaseresponse_2.SearchBaseResponseType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.ClientProfileStatusType;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClientProfileResponseType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"clientProfileStatus"})
public class ClientProfileResponseType extends SearchBaseResponseType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "ClientProfileStatus")
  protected List<ClientProfileStatusType> clientProfileStatus;
  
  public List<ClientProfileStatusType> getClientProfileStatus() {
    if (this.clientProfileStatus == null)
      this.clientProfileStatus = new ArrayList<ClientProfileStatusType>(); 
    return this.clientProfileStatus;
  }
}
