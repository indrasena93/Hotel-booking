package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.schemas.framework.searchbaserequest_2.SearchBaseRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.ProducerIdAndGovernmentIdType;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProducerIdAndGovernmentIdRequestType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"producerAndGovernmentId"})
public class ProducerIdAndGovernmentIdRequestType extends SearchBaseRequestType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "ProducerAndGovernmentId")
  protected List<ProducerIdAndGovernmentIdType> producerAndGovernmentId;
  
  public List<ProducerIdAndGovernmentIdType> getProducerAndGovernmentId() {
    if (this.producerAndGovernmentId == null)
      this.producerAndGovernmentId = new ArrayList<ProducerIdAndGovernmentIdType>(); 
    return this.producerAndGovernmentId;
  }
}
