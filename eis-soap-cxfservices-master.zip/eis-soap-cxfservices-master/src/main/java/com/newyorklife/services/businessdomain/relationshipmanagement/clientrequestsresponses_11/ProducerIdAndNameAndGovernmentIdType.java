package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.ProducerIdAndNameType;
import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProducerIdAndNameAndGovernmentIdType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"producerAndName", "governmentId"})
public class ProducerIdAndNameAndGovernmentIdType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "ProducerAndName")
  protected ProducerIdAndNameType producerAndName;
  
  @XmlElement(name = "GovernmentId")
  protected String governmentId;
  
  public ProducerIdAndNameType getProducerAndName() {
    return this.producerAndName;
  }
  
  public void setProducerAndName(ProducerIdAndNameType paramProducerIdAndNameType) {
    this.producerAndName = paramProducerIdAndNameType;
  }
  
  public String getGovernmentId() {
    return this.governmentId;
  }
  
  public void setGovernmentId(String paramString) {
    this.governmentId = paramString;
  }
}
