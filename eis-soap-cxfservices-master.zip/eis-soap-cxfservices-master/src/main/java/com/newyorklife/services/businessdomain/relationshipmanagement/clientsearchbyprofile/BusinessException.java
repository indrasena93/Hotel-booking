package com.newyorklife.services.businessdomain.relationshipmanagement.clientsearchbyprofile;

import com.newyorklife.schemas.framework.businessexception_2.BusinessExceptionType;
import javax.xml.ws.WebFault;

@WebFault(name = "BusinessException", targetNamespace = "http://newyorklife.com/schemas/framework/businessexception")
public class BusinessException extends Exception {
  private BusinessExceptionType faultInfo;
  
  public BusinessException(String paramString, BusinessExceptionType paramBusinessExceptionType) {
    super(paramString);
    this.faultInfo = paramBusinessExceptionType;
  }
  
  public BusinessException(String paramString, BusinessExceptionType paramBusinessExceptionType, Throwable paramThrowable) {
    super(paramString, paramThrowable);
    this.faultInfo = paramBusinessExceptionType;
  }
  
  public BusinessExceptionType getFaultInfo() {
    return this.faultInfo;
  }
}
