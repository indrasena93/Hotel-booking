package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.schemas.cim.common.governmenttaxtype_3.GovernmentTaxType;
import java.io.Serializable;
import java.util.Calendar;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
import org.w3._2001.xmlschema.Adapter3;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "GovtIDAndDOBType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"governmentId", "birthDt"})
public class GovtIDAndDOBType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "GovernmentId")
  protected GovernmentTaxType governmentId;
  
  @XmlElement(name = "BirthDt", type = String.class)
  @XmlJavaTypeAdapter(Adapter3.class)
  protected Calendar birthDt;
  
  public GovernmentTaxType getGovernmentId() {
    return this.governmentId;
  }
  
  public void setGovernmentId(GovernmentTaxType paramGovernmentTaxType) {
    this.governmentId = paramGovernmentTaxType;
  }
  
  public Calendar getBirthDt() {
    return this.birthDt;
  }
  
  public void setBirthDt(Calendar paramCalendar) {
    this.birthDt = paramCalendar;
  }
}
