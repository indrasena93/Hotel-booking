package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.schemas.cim.common.name_4.NameType;
import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "NameAndCityAdType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"name", "cityAd"})
public class NameAndCityAdType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "Name")
  protected NameType name;
  
  @XmlElement(name = "CityAd")
  protected String cityAd;
  
  public NameType getName() {
    return this.name;
  }
  
  public void setName(NameType paramNameType) {
    this.name = paramNameType;
  }
  
  public String getCityAd() {
    return this.cityAd;
  }
  
  public void setCityAd(String paramString) {
    this.cityAd = paramString;
  }
}
