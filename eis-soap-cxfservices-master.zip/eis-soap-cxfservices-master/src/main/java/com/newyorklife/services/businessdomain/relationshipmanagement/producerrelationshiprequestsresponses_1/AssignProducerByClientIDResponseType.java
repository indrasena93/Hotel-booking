package com.newyorklife.services.businessdomain.relationshipmanagement.producerrelationshiprequestsresponses_1;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import com.newyorklife.schemas.cim.producer.producerprofile_9.ProducerProfileType;
import com.newyorklife.schemas.framework.baseresponse_2.BaseResponseType;
import com.newyorklife.schemas.framework.statusmessage_2.StatusMessageType;


@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AssignProducerByClientIDResponseType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/producerrelationshiprequestsresponses", propOrder = {"producerProfileAndStatusType"})
public class AssignProducerByClientIDResponseType extends BaseResponseType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "ProducerProfileAndStatusType")
  protected List<AssignProducerByClientIDResponseType.ProducerProfileAndStatusType> producerProfileAndStatusType;
  
  public List<AssignProducerByClientIDResponseType.ProducerProfileAndStatusType> getProducerProfileAndStatusType() {
    if (this.producerProfileAndStatusType == null)
      this.producerProfileAndStatusType = new ArrayList<AssignProducerByClientIDResponseType.ProducerProfileAndStatusType>(); 
    return this.producerProfileAndStatusType;
  }
  
  /**
   * <p>Java class for anonymous complex type.
   * 
   * <p>The following schema fragment specifies the expected content contained within this class.
   * 
   * <pre>
   * &lt;complexType>
   *   &lt;complexContent>
   *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
   *       &lt;sequence>
   *         &lt;element name="StatusMessage" type="{http://newyorklife.com/schemas/framework/statusmessage}StatusMessageType" minOccurs="0"/>
   *         &lt;element name="ProducerProfile" type="{http://newyorklife.com/schemas/cim/producer/producerprofile}ProducerProfileType" minOccurs="0"/>
   *       &lt;/sequence>
   *     &lt;/restriction>
   *   &lt;/complexContent>
   * &lt;/complexType>
   * </pre>
   * 
   * 
   */
  @XmlAccessorType(XmlAccessType.FIELD)
  @XmlType(name = "", propOrder = {
      "statusMessage",
      "producerProfile"
  })
  public static class ProducerProfileAndStatusType
      implements Serializable
  {

      private final static long serialVersionUID = -6026937020915831338L;
      @XmlElement(name = "StatusMessage")
      protected StatusMessageType statusMessage;
      @XmlElement(name = "ProducerProfile")
      protected ProducerProfileType producerProfile;

      /**
       * Gets the value of the statusMessage property.
       * 
       * @return
       *     possible object is
       *     {@link StatusMessageType }
       *     
       */
      public StatusMessageType getStatusMessage() {
          return statusMessage;
      }

      /**
       * Sets the value of the statusMessage property.
       * 
       * @param value
       *     allowed object is
       *     {@link StatusMessageType }
       *     
       */
      public void setStatusMessage(StatusMessageType value) {
          this.statusMessage = value;
      }

      /**
       * Gets the value of the producerProfile property.
       * 
       * @return
       *     possible object is
       *     {@link ProducerProfileType }
       *     
       */
      public ProducerProfileType getProducerProfile() {
          return producerProfile;
      }

      /**
       * Sets the value of the producerProfile property.
       * 
       * @param value
       *     allowed object is
       *     {@link ProducerProfileType }
       *     
       */
      public void setProducerProfile(ProducerProfileType value) {
          this.producerProfile = value;
      }

  }

}
