package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.schemas.framework.baseresponse_2.BaseResponseType;
import com.newyorklife.schemas.framework.statusmessage_2.StatusMessageType;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StatusResponseType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"statusMessage"})
public class StatusResponseType extends BaseResponseType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "StatusMessage")
  protected List<StatusMessageType> statusMessage;
  
  public List<StatusMessageType> getStatusMessage() {
    if (this.statusMessage == null)
      this.statusMessage = new ArrayList<StatusMessageType>(); 
    return this.statusMessage;
  }
}
