package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.schemas.framework.statusmessage_2.StatusMessageType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.AddressContractType;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ClientUnclaimedMailAndStatus", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"statusMessage", "clientId", "addressContract"})
public class ClientUnclaimedMailAndStatus implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "StatusMessage")
  protected StatusMessageType statusMessage;
  
  @XmlElement(name = "ClientId")
  protected String clientId;
  
  @XmlElement(name = "AddressContract")
  protected List<AddressContractType> addressContract;
  
  public StatusMessageType getStatusMessage() {
    return this.statusMessage;
  }
  
  public void setStatusMessage(StatusMessageType paramStatusMessageType) {
    this.statusMessage = paramStatusMessageType;
  }
  
  public String getClientId() {
    return this.clientId;
  }
  
  public void setClientId(String paramString) {
    this.clientId = paramString;
  }
  
  public List<AddressContractType> getAddressContract() {
    if (this.addressContract == null)
      this.addressContract = new ArrayList<AddressContractType>(); 
    return this.addressContract;
  }
}
