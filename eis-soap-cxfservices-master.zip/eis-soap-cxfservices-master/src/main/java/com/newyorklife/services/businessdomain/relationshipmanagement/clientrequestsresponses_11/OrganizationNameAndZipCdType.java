package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.schemas.cim.common.name_4.NameType;
import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OrganizationNameAndZipCdType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"name", "postalCd", "postalPlus4Cd"})
public class OrganizationNameAndZipCdType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "Name")
  protected NameType name;
  
  @XmlElement(name = "PostalCd")
  protected String postalCd;
  
  @XmlElement(name = "PostalPlus4Cd")
  protected String postalPlus4Cd;
  
  public NameType getName() {
    return this.name;
  }
  
  public void setName(NameType paramNameType) {
    this.name = paramNameType;
  }
  
  public String getPostalCd() {
    return this.postalCd;
  }
  
  public void setPostalCd(String paramString) {
    this.postalCd = paramString;
  }
  
  public String getPostalPlus4Cd() {
    return this.postalPlus4Cd;
  }
  
  public void setPostalPlus4Cd(String paramString) {
    this.postalPlus4Cd = paramString;
  }
}
