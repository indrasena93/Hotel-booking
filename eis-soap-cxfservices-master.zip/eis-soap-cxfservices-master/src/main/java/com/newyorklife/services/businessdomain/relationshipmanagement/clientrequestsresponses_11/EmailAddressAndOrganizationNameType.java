package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.schemas.cim.common.name_4.NameType;
import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EmailAddressAndOrganizationNameType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"emailAd", "organizationNm"})
public class EmailAddressAndOrganizationNameType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "EmailAd")
  protected String emailAd;
  
  @XmlElement(name = "OrganizationNm")
  protected NameType organizationNm;
  
  public String getEmailAd() {
    return this.emailAd;
  }
  
  public void setEmailAd(String paramString) {
    this.emailAd = paramString;
  }
  
  public NameType getOrganizationNm() {
    return this.organizationNm;
  }
  
  public void setOrganizationNm(NameType paramNameType) {
    this.organizationNm = paramNameType;
  }
}
