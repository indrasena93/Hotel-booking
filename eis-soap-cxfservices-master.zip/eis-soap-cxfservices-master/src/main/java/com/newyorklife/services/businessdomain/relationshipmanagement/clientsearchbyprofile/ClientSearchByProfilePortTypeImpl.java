package com.newyorklife.services.businessdomain.relationshipmanagement.clientsearchbyprofile;

import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.ClientProfileResponseType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.SearchClientByProfileUsingWeightsRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientsearchbyprofile.BusinessException;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientsearchbyprofile.ClientSearchByProfilePortType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientsearchbyprofile.FatalException;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientsearchbyprofile.SystemException;
import com.newyorklife.webservice.implementation.delegate.ClientSearchByProfileDelegate;
import java.util.logging.Logger;
import javax.jws.WebService;

@WebService(serviceName = "ClientSearchByProfileService", portName = "ClientSearchByProfilePort", targetNamespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientsearchbyprofile", endpointInterface = "com.newyorklife.services.businessdomain.relationshipmanagement.clientsearchbyprofile.ClientSearchByProfilePortType")
public class ClientSearchByProfilePortTypeImpl implements ClientSearchByProfilePortType {
  private static final Logger LOG = Logger.getLogger(com.newyorklife.services.businessdomain.relationshipmanagement.clientsearchbyprofile.ClientSearchByProfilePortTypeImpl.class.getName());
  
  public ClientProfileResponseType searchClientByProfileUsingWeights(SearchClientByProfileUsingWeightsRequestType paramSearchClientByProfileUsingWeightsRequestType) throws BusinessException, FatalException, SystemException {
    LOG.info("Executing operation searchClientForMatchUsingWeights");
    try {
      return ClientSearchByProfileDelegate.searchClientByProfileUsingWeights(paramSearchClientByProfileUsingWeightsRequestType);
    } catch (Exception exception) {
      exception.printStackTrace();
      throw new RuntimeException(exception);
    } 
  }
}

