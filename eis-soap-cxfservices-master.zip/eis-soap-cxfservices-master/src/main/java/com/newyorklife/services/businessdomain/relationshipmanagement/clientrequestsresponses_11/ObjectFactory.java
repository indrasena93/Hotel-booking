package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.AddressContractType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.ChangeClientReturnedMailIndicatorRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.ChangeClientReturnedMailIndicatorType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.ClientIdRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.ClientProfileResponseType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.ClientProfileStatusType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.ClientRelationshipResponseType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.ClientRoleType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.ClientRolesType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.ClientUnclaimedMailAndStatus;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.ClientUnclaimedMailIndicatorAndStatus;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.ClientUnclaimedMailIndicatorResponseType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.ClientUnclaimedMailResponseType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.EmailAddressAndDOBRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.EmailAddressAndDOBType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.EmailAddressAndNameRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.EmailAddressAndNameType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.EmailAddressAndOrganizationNameRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.EmailAddressAndOrganizationNameType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.EmailAddressRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.GovtIDAndDOBType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.GovtIDAndNameType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.GovtIDAndOrganizationNameType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.NameAndBirthDtType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.NameAndCityAdType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.NameAndRoleCdType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.NameAndStateCdType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.NameAndZipCdType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.OrganizationNameAndBirthDtType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.OrganizationNameAndCityAdType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.OrganizationNameAndPhoneType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.OrganizationNameAndRoleCdType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.OrganizationNameAndStateCdType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.OrganizationNameAndZipCdType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.ProducerIdAndGovernmentIdRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.ProducerIdAndGovernmentIdType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.ProducerIdAndNameAndBirthDateRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.ProducerIdAndNameAndBirthDateType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.ProducerIdAndNameAndGovernmentIdRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.ProducerIdAndNameAndGovernmentIdType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.ProducerIdAndNameRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.ProducerIdAndNameType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.SearchClientByContractIDRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.SearchClientByGovernmentIDRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.SearchClientByGovtIDAndDOBRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.SearchClientByGovtIDAndNameRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.SearchClientByGovtIDAndOrganizationNameRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.SearchClientByGovtIDRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.SearchClientByNameAndCityRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.SearchClientByNameAndDOBRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.SearchClientByNameAndRoleRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.SearchClientByNameAndStateRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.SearchClientByNameAndZipRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.SearchClientByNameRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.SearchClientByOrganizationNameAndCityRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.SearchClientByOrganizationNameAndDOBRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.SearchClientByOrganizationNameAndPhoneRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.SearchClientByOrganizationNameAndRoleRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.SearchClientByOrganizationNameAndStateRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.SearchClientByOrganizationNameAndZipRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.SearchClientByOrganizationNameRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.SearchClientByPhoneRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.SearchClientByProfileUsingWeightsRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.StatusResponseType;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

@XmlRegistry
public class ObjectFactory {
  private static final QName _RetrieveClientProfileRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "RetrieveClientProfileRequest");
  
  private static final QName _SearchClientByPhoneRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "SearchClientByPhoneRequest");
  
  private static final QName _SearchClientByGovtIDRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "SearchClientByGovtIDRequest");
  
  private static final QName _SearchClientByNameAndCityRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "SearchClientByNameAndCityRequest");
  
  private static final QName _ClientUnclaimedMailIndicatorResponse_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "ClientUnclaimedMailIndicatorResponse");
  
  private static final QName _SearchClientByEmailAddressAndOrganizationNameRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "SearchClientByEmailAddressAndOrganizationNameRequest");
  
  private static final QName _SearchClientByOrganizationNameAndZipRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "SearchClientByOrganizationNameAndZipRequest");
  
  private static final QName _SearchClientByContractIDRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "SearchClientByContractIDRequest");
  
  private static final QName _SearchClientByGovtIDAndNameRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "SearchClientByGovtIDAndNameRequest");
  
  private static final QName _SearchCustomerByProducerIDAndCustomerNameRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "SearchCustomerByProducerIDAndCustomerNameRequest");
  
  private static final QName _SearchClientByGovernmentIDRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "SearchClientByGovernmentIDRequest");
  
  private static final QName _SearchClientByOrganizationNameAndCityRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "SearchClientByOrganizationNameAndCityRequest");
  
  private static final QName _SearchClientByNameAndRoleRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "SearchClientByNameAndRoleRequest");
  
  private static final QName _SearchClientByNameAndZipRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "SearchClientByNameAndZipRequest");
  
  private static final QName _SearchClientByEmailAddressAndDOBRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "SearchClientByEmailAddressAndDOBRequest");
  
  private static final QName _SearchClientByEmailAddressRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "SearchClientByEmailAddressRequest");
  
  private static final QName _RetrieveClientProfileAndContactInformationRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "RetrieveClientProfileAndContactInformationRequest");
  
  private static final QName _ChangeClientReturnedMailIndicatorResponse_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "ChangeClientReturnedMailIndicatorResponse");
  
  private static final QName _SearchCustomerByProducerIDAndBirthDateAndCustomerNameRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "SearchCustomerByProducerIDAndBirthDateAndCustomerNameRequest");
  
  private static final QName _SearchCustomerByProducerIDAndGovernmentIDAndCustomerNameRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "SearchCustomerByProducerIDAndGovernmentIDAndCustomerNameRequest");
  
  private static final QName _SearchClientByOrganizationNameAndRoleRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "SearchClientByOrganizationNameAndRoleRequest");
  
  private static final QName _ClientAssociatedContractOwnersResponse_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "ClientAssociatedContractOwnersResponse");
  
  private static final QName _SearchCustomerByProducerIDAndOrganizationNameRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "SearchCustomerByProducerIDAndOrganizationNameRequest");
  
  private static final QName _SearchClientByNameAndStateRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "SearchClientByNameAndStateRequest");
  
  private static final QName _SearchClientByNameAndDOBRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "SearchClientByNameAndDOBRequest");
  
  private static final QName _SearchCustomerByProducerIDAndGovernmentIDAndOrganizationNameRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "SearchCustomerByProducerIDAndGovernmentIDAndOrganizationNameRequest");
  
  private static final QName _SearchClientByEmailAddressAndNameRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "SearchClientByEmailAddressAndNameRequest");
  
  private static final QName _SearchClientByGovtIDAndDOBRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "SearchClientByGovtIDAndDOBRequest");
  
  private static final QName _SearchClientByOrganizationNameRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "SearchClientByOrganizationNameRequest");
  
  private static final QName _ClientProfileResponse_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "ClientProfileResponse");
  
  private static final QName _RetrieveAllClientReturnedMailRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "RetrieveAllClientReturnedMailRequest");
  
  private static final QName _RetrieveClientReturnedMailIndicatorRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "RetrieveClientReturnedMailIndicatorRequest");
  
  private static final QName _SearchClientByOrganizationNameAndStateRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "SearchClientByOrganizationNameAndStateRequest");
  
  private static final QName _ClientUnclaimedMailResponse_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "ClientUnclaimedMailResponse");
  
  private static final QName _SearchClientByGovtIDAndOrganizationNameRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "SearchClientByGovtIDAndOrganizationNameRequest");
  
  private static final QName _ChangeClientReturnedMailIndicatorRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "ChangeClientReturnedMailIndicatorRequest");
  
  private static final QName _SearchClientByNameRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "SearchClientByNameRequest");
  
  private static final QName _SearchCustomerByProducerIDAndGovernmentIDRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "SearchCustomerByProducerIDAndGovernmentIDRequest");
  
  private static final QName _SearchClientByOrganizationNameAndPhoneRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "SearchClientByOrganizationNameAndPhoneRequest");
  
  private static final QName _RetrieveClientAssociatedContractOwnersRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", "RetrieveClientAssociatedContractOwnersRequest");
  
  public ProducerIdAndNameAndBirthDateType createProducerIdAndNameAndBirthDateType() {
    return new ProducerIdAndNameAndBirthDateType();
  }
  
  public ProducerIdAndGovernmentIdRequestType createProducerIdAndGovernmentIdRequestType() {
    return new ProducerIdAndGovernmentIdRequestType();
  }
  
  public NameAndStateCdType createNameAndStateCdType() {
    return new NameAndStateCdType();
  }
  
  public GovtIDAndDOBType createGovtIDAndDOBType() {
    return new GovtIDAndDOBType();
  }
  
  public OrganizationNameAndZipCdType createOrganizationNameAndZipCdType() {
    return new OrganizationNameAndZipCdType();
  }
  
  public ClientIdRequestType createClientIdRequestType() {
    return new ClientIdRequestType();
  }
  
  public EmailAddressAndDOBRequestType createEmailAddressAndDOBRequestType() {
    return new EmailAddressAndDOBRequestType();
  }
  
  public OrganizationNameAndCityAdType createOrganizationNameAndCityAdType() {
    return new OrganizationNameAndCityAdType();
  }
  
  public ClientRelationshipResponseType createClientRelationshipResponseType() {
    return new ClientRelationshipResponseType();
  }
  
  public SearchClientByGovtIDAndNameRequestType createSearchClientByGovtIDAndNameRequestType() {
    return new SearchClientByGovtIDAndNameRequestType();
  }
  
  public SearchClientByNameAndRoleRequestType createSearchClientByNameAndRoleRequestType() {
    return new SearchClientByNameAndRoleRequestType();
  }
  
  public EmailAddressAndOrganizationNameRequestType createEmailAddressAndOrganizationNameRequestType() {
    return new EmailAddressAndOrganizationNameRequestType();
  }
  
  public ClientRoleType createClientRoleType() {
    return new ClientRoleType();
  }
  
  public ClientUnclaimedMailResponseType createClientUnclaimedMailResponseType() {
    return new ClientUnclaimedMailResponseType();
  }
  
  public NameAndCityAdType createNameAndCityAdType() {
    return new NameAndCityAdType();
  }
  
  public SearchClientByGovernmentIDRequestType createSearchClientByGovernmentIDRequestType() {
    return new SearchClientByGovernmentIDRequestType();
  }
  
  public NameAndRoleCdType createNameAndRoleCdType() {
    return new NameAndRoleCdType();
  }
  
  public SearchClientByGovtIDAndOrganizationNameRequestType createSearchClientByGovtIDAndOrganizationNameRequestType() {
    return new SearchClientByGovtIDAndOrganizationNameRequestType();
  }
  
  public ProducerIdAndNameAndGovernmentIdRequestType createProducerIdAndNameAndGovernmentIdRequestType() {
    return new ProducerIdAndNameAndGovernmentIdRequestType();
  }
  
  public SearchClientByOrganizationNameAndRoleRequestType createSearchClientByOrganizationNameAndRoleRequestType() {
    return new SearchClientByOrganizationNameAndRoleRequestType();
  }
  
  public OrganizationNameAndStateCdType createOrganizationNameAndStateCdType() {
    return new OrganizationNameAndStateCdType();
  }
  
  public NameAndBirthDtType createNameAndBirthDtType() {
    return new NameAndBirthDtType();
  }
  
  public EmailAddressAndDOBType createEmailAddressAndDOBType() {
    return new EmailAddressAndDOBType();
  }
  
  public ProducerIdAndGovernmentIdType createProducerIdAndGovernmentIdType() {
    return new ProducerIdAndGovernmentIdType();
  }
  
  public ChangeClientReturnedMailIndicatorType createChangeClientReturnedMailIndicatorType() {
    return new ChangeClientReturnedMailIndicatorType();
  }
  
  public SearchClientByOrganizationNameAndStateRequestType createSearchClientByOrganizationNameAndStateRequestType() {
    return new SearchClientByOrganizationNameAndStateRequestType();
  }
  
  public SearchClientByNameAndCityRequestType createSearchClientByNameAndCityRequestType() {
    return new SearchClientByNameAndCityRequestType();
  }
  
  public SearchClientByPhoneRequestType createSearchClientByPhoneRequestType() {
    return new SearchClientByPhoneRequestType();
  }
  
  public NameAndZipCdType createNameAndZipCdType() {
    return new NameAndZipCdType();
  }
  
  public ClientUnclaimedMailIndicatorResponseType createClientUnclaimedMailIndicatorResponseType() {
    return new ClientUnclaimedMailIndicatorResponseType();
  }
  
  public SearchClientByOrganizationNameAndZipRequestType createSearchClientByOrganizationNameAndZipRequestType() {
    return new SearchClientByOrganizationNameAndZipRequestType();
  }
  
  public ChangeClientReturnedMailIndicatorRequestType createChangeClientReturnedMailIndicatorRequestType() {
    return new ChangeClientReturnedMailIndicatorRequestType();
  }
  
  public EmailAddressAndNameType createEmailAddressAndNameType() {
    return new EmailAddressAndNameType();
  }
  
  public ClientProfileStatusType createClientProfileStatusType() {
    return new ClientProfileStatusType();
  }
  
  public ProducerIdAndNameRequestType createProducerIdAndNameRequestType() {
    return new ProducerIdAndNameRequestType();
  }
  
  public OrganizationNameAndBirthDtType createOrganizationNameAndBirthDtType() {
    return new OrganizationNameAndBirthDtType();
  }
  
  public SearchClientByNameAndStateRequestType createSearchClientByNameAndStateRequestType() {
    return new SearchClientByNameAndStateRequestType();
  }
  
  public StatusResponseType createStatusResponseType() {
    return new StatusResponseType();
  }
  
  public SearchClientByProfileUsingWeightsRequestType.ClientProfile createSearchClientByProfileUsingWeightsRequestTypeClientProfile() {
    return new SearchClientByProfileUsingWeightsRequestType.ClientProfile();
  }
  
  public GovtIDAndNameType createGovtIDAndNameType() {
    return new GovtIDAndNameType();
  }
  
  public ProducerIdAndNameType createProducerIdAndNameType() {
    return new ProducerIdAndNameType();
  }
  
  public SearchClientByGovtIDRequestType createSearchClientByGovtIDRequestType() {
    return new SearchClientByGovtIDRequestType();
  }
  
  public SearchClientByGovtIDAndDOBRequestType createSearchClientByGovtIDAndDOBRequestType() {
    return new SearchClientByGovtIDAndDOBRequestType();
  }
  
  public GovtIDAndOrganizationNameType createGovtIDAndOrganizationNameType() {
    return new GovtIDAndOrganizationNameType();
  }
  
  public EmailAddressAndOrganizationNameType createEmailAddressAndOrganizationNameType() {
    return new EmailAddressAndOrganizationNameType();
  }
  
  public AddressContractType createAddressContractType() {
    return new AddressContractType();
  }
  
  public SearchClientByOrganizationNameAndDOBRequestType createSearchClientByOrganizationNameAndDOBRequestType() {
    return new SearchClientByOrganizationNameAndDOBRequestType();
  }
  
  public SearchClientByOrganizationNameRequestType createSearchClientByOrganizationNameRequestType() {
    return new SearchClientByOrganizationNameRequestType();
  }
  
  public SearchClientByProfileUsingWeightsRequestType createSearchClientByProfileUsingWeightsRequestType() {
    return new SearchClientByProfileUsingWeightsRequestType();
  }
  
  public SearchClientByContractIDRequestType createSearchClientByContractIDRequestType() {
    return new SearchClientByContractIDRequestType();
  }
  
  public ClientUnclaimedMailAndStatus createClientUnclaimedMailAndStatus() {
    return new ClientUnclaimedMailAndStatus();
  }
  
  public OrganizationNameAndPhoneType createOrganizationNameAndPhoneType() {
    return new OrganizationNameAndPhoneType();
  }
  
  public ProducerIdAndNameAndGovernmentIdType createProducerIdAndNameAndGovernmentIdType() {
    return new ProducerIdAndNameAndGovernmentIdType();
  }
  
  public OrganizationNameAndRoleCdType createOrganizationNameAndRoleCdType() {
    return new OrganizationNameAndRoleCdType();
  }
  
  public SearchClientByNameRequestType createSearchClientByNameRequestType() {
    return new SearchClientByNameRequestType();
  }
  
  public EmailAddressRequestType createEmailAddressRequestType() {
    return new EmailAddressRequestType();
  }
  
  public EmailAddressAndNameRequestType createEmailAddressAndNameRequestType() {
    return new EmailAddressAndNameRequestType();
  }
  
  public SearchClientByNameAndDOBRequestType createSearchClientByNameAndDOBRequestType() {
    return new SearchClientByNameAndDOBRequestType();
  }
  
  public SearchClientByNameAndZipRequestType createSearchClientByNameAndZipRequestType() {
    return new SearchClientByNameAndZipRequestType();
  }
  
  public ClientUnclaimedMailIndicatorAndStatus createClientUnclaimedMailIndicatorAndStatus() {
    return new ClientUnclaimedMailIndicatorAndStatus();
  }
  
  public ProducerIdAndNameAndBirthDateRequestType createProducerIdAndNameAndBirthDateRequestType() {
    return new ProducerIdAndNameAndBirthDateRequestType();
  }
  
  public ClientRolesType createClientRolesType() {
    return new ClientRolesType();
  }
  
  public SearchClientByOrganizationNameAndCityRequestType createSearchClientByOrganizationNameAndCityRequestType() {
    return new SearchClientByOrganizationNameAndCityRequestType();
  }
  
  public SearchClientByOrganizationNameAndPhoneRequestType createSearchClientByOrganizationNameAndPhoneRequestType() {
    return new SearchClientByOrganizationNameAndPhoneRequestType();
  }
  
  public ClientProfileResponseType createClientProfileResponseType() {
    return new ClientProfileResponseType();
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "RetrieveClientProfileRequest")
  public JAXBElement<ClientIdRequestType> createRetrieveClientProfileRequest(ClientIdRequestType paramClientIdRequestType) {
    return new JAXBElement<ClientIdRequestType>(_RetrieveClientProfileRequest_QNAME, ClientIdRequestType.class, null, paramClientIdRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "SearchClientByPhoneRequest")
  public JAXBElement<SearchClientByPhoneRequestType> createSearchClientByPhoneRequest(SearchClientByPhoneRequestType paramSearchClientByPhoneRequestType) {
    return new JAXBElement<SearchClientByPhoneRequestType>(_SearchClientByPhoneRequest_QNAME, SearchClientByPhoneRequestType.class, null, paramSearchClientByPhoneRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "SearchClientByGovtIDRequest")
  public JAXBElement<SearchClientByGovtIDRequestType> createSearchClientByGovtIDRequest(SearchClientByGovtIDRequestType paramSearchClientByGovtIDRequestType) {
    return new JAXBElement<SearchClientByGovtIDRequestType>(_SearchClientByGovtIDRequest_QNAME, SearchClientByGovtIDRequestType.class, null, paramSearchClientByGovtIDRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "SearchClientByNameAndCityRequest")
  public JAXBElement<SearchClientByNameAndCityRequestType> createSearchClientByNameAndCityRequest(SearchClientByNameAndCityRequestType paramSearchClientByNameAndCityRequestType) {
    return new JAXBElement<SearchClientByNameAndCityRequestType>(_SearchClientByNameAndCityRequest_QNAME, SearchClientByNameAndCityRequestType.class, null, paramSearchClientByNameAndCityRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "ClientUnclaimedMailIndicatorResponse")
  public JAXBElement<ClientUnclaimedMailIndicatorResponseType> createClientUnclaimedMailIndicatorResponse(ClientUnclaimedMailIndicatorResponseType paramClientUnclaimedMailIndicatorResponseType) {
    return new JAXBElement<ClientUnclaimedMailIndicatorResponseType>(_ClientUnclaimedMailIndicatorResponse_QNAME, ClientUnclaimedMailIndicatorResponseType.class, null, paramClientUnclaimedMailIndicatorResponseType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "SearchClientByEmailAddressAndOrganizationNameRequest")
  public JAXBElement<EmailAddressAndOrganizationNameRequestType> createSearchClientByEmailAddressAndOrganizationNameRequest(EmailAddressAndOrganizationNameRequestType paramEmailAddressAndOrganizationNameRequestType) {
    return new JAXBElement<EmailAddressAndOrganizationNameRequestType>(_SearchClientByEmailAddressAndOrganizationNameRequest_QNAME, EmailAddressAndOrganizationNameRequestType.class, null, paramEmailAddressAndOrganizationNameRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "SearchClientByOrganizationNameAndZipRequest")
  public JAXBElement<SearchClientByOrganizationNameAndZipRequestType> createSearchClientByOrganizationNameAndZipRequest(SearchClientByOrganizationNameAndZipRequestType paramSearchClientByOrganizationNameAndZipRequestType) {
    return new JAXBElement<SearchClientByOrganizationNameAndZipRequestType>(_SearchClientByOrganizationNameAndZipRequest_QNAME, SearchClientByOrganizationNameAndZipRequestType.class, null, paramSearchClientByOrganizationNameAndZipRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "SearchClientByContractIDRequest")
  public JAXBElement<SearchClientByContractIDRequestType> createSearchClientByContractIDRequest(SearchClientByContractIDRequestType paramSearchClientByContractIDRequestType) {
    return new JAXBElement<SearchClientByContractIDRequestType>(_SearchClientByContractIDRequest_QNAME, SearchClientByContractIDRequestType.class, null, paramSearchClientByContractIDRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "SearchClientByGovtIDAndNameRequest")
  public JAXBElement<SearchClientByGovtIDAndNameRequestType> createSearchClientByGovtIDAndNameRequest(SearchClientByGovtIDAndNameRequestType paramSearchClientByGovtIDAndNameRequestType) {
    return new JAXBElement<SearchClientByGovtIDAndNameRequestType>(_SearchClientByGovtIDAndNameRequest_QNAME, SearchClientByGovtIDAndNameRequestType.class, null, paramSearchClientByGovtIDAndNameRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "SearchCustomerByProducerIDAndCustomerNameRequest")
  public JAXBElement<ProducerIdAndNameRequestType> createSearchCustomerByProducerIDAndCustomerNameRequest(ProducerIdAndNameRequestType paramProducerIdAndNameRequestType) {
    return new JAXBElement<ProducerIdAndNameRequestType>(_SearchCustomerByProducerIDAndCustomerNameRequest_QNAME, ProducerIdAndNameRequestType.class, null, paramProducerIdAndNameRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "SearchClientByGovernmentIDRequest")
  public JAXBElement<SearchClientByGovernmentIDRequestType> createSearchClientByGovernmentIDRequest(SearchClientByGovernmentIDRequestType paramSearchClientByGovernmentIDRequestType) {
    return new JAXBElement<SearchClientByGovernmentIDRequestType>(_SearchClientByGovernmentIDRequest_QNAME, SearchClientByGovernmentIDRequestType.class, null, paramSearchClientByGovernmentIDRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "SearchClientByOrganizationNameAndCityRequest")
  public JAXBElement<SearchClientByOrganizationNameAndCityRequestType> createSearchClientByOrganizationNameAndCityRequest(SearchClientByOrganizationNameAndCityRequestType paramSearchClientByOrganizationNameAndCityRequestType) {
    return new JAXBElement<SearchClientByOrganizationNameAndCityRequestType>(_SearchClientByOrganizationNameAndCityRequest_QNAME, SearchClientByOrganizationNameAndCityRequestType.class, null, paramSearchClientByOrganizationNameAndCityRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "SearchClientByNameAndRoleRequest")
  public JAXBElement<SearchClientByNameAndRoleRequestType> createSearchClientByNameAndRoleRequest(SearchClientByNameAndRoleRequestType paramSearchClientByNameAndRoleRequestType) {
    return new JAXBElement<SearchClientByNameAndRoleRequestType>(_SearchClientByNameAndRoleRequest_QNAME, SearchClientByNameAndRoleRequestType.class, null, paramSearchClientByNameAndRoleRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "SearchClientByNameAndZipRequest")
  public JAXBElement<SearchClientByNameAndZipRequestType> createSearchClientByNameAndZipRequest(SearchClientByNameAndZipRequestType paramSearchClientByNameAndZipRequestType) {
    return new JAXBElement<SearchClientByNameAndZipRequestType>(_SearchClientByNameAndZipRequest_QNAME, SearchClientByNameAndZipRequestType.class, null, paramSearchClientByNameAndZipRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "SearchClientByEmailAddressAndDOBRequest")
  public JAXBElement<EmailAddressAndDOBRequestType> createSearchClientByEmailAddressAndDOBRequest(EmailAddressAndDOBRequestType paramEmailAddressAndDOBRequestType) {
    return new JAXBElement<EmailAddressAndDOBRequestType>(_SearchClientByEmailAddressAndDOBRequest_QNAME, EmailAddressAndDOBRequestType.class, null, paramEmailAddressAndDOBRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "SearchClientByEmailAddressRequest")
  public JAXBElement<EmailAddressRequestType> createSearchClientByEmailAddressRequest(EmailAddressRequestType paramEmailAddressRequestType) {
    return new JAXBElement<EmailAddressRequestType>(_SearchClientByEmailAddressRequest_QNAME, EmailAddressRequestType.class, null, paramEmailAddressRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "RetrieveClientProfileAndContactInformationRequest")
  public JAXBElement<ClientIdRequestType> createRetrieveClientProfileAndContactInformationRequest(ClientIdRequestType paramClientIdRequestType) {
    return new JAXBElement<ClientIdRequestType>(_RetrieveClientProfileAndContactInformationRequest_QNAME, ClientIdRequestType.class, null, paramClientIdRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "ChangeClientReturnedMailIndicatorResponse")
  public JAXBElement<StatusResponseType> createChangeClientReturnedMailIndicatorResponse(StatusResponseType paramStatusResponseType) {
    return new JAXBElement<StatusResponseType>(_ChangeClientReturnedMailIndicatorResponse_QNAME, StatusResponseType.class, null, paramStatusResponseType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "SearchCustomerByProducerIDAndBirthDateAndCustomerNameRequest")
  public JAXBElement<ProducerIdAndNameAndBirthDateRequestType> createSearchCustomerByProducerIDAndBirthDateAndCustomerNameRequest(ProducerIdAndNameAndBirthDateRequestType paramProducerIdAndNameAndBirthDateRequestType) {
    return new JAXBElement<ProducerIdAndNameAndBirthDateRequestType>(_SearchCustomerByProducerIDAndBirthDateAndCustomerNameRequest_QNAME, ProducerIdAndNameAndBirthDateRequestType.class, null, paramProducerIdAndNameAndBirthDateRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "SearchCustomerByProducerIDAndGovernmentIDAndCustomerNameRequest")
  public JAXBElement<ProducerIdAndNameAndGovernmentIdRequestType> createSearchCustomerByProducerIDAndGovernmentIDAndCustomerNameRequest(ProducerIdAndNameAndGovernmentIdRequestType paramProducerIdAndNameAndGovernmentIdRequestType) {
    return new JAXBElement<ProducerIdAndNameAndGovernmentIdRequestType>(_SearchCustomerByProducerIDAndGovernmentIDAndCustomerNameRequest_QNAME, ProducerIdAndNameAndGovernmentIdRequestType.class, null, paramProducerIdAndNameAndGovernmentIdRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "SearchClientByOrganizationNameAndRoleRequest")
  public JAXBElement<SearchClientByOrganizationNameAndRoleRequestType> createSearchClientByOrganizationNameAndRoleRequest(SearchClientByOrganizationNameAndRoleRequestType paramSearchClientByOrganizationNameAndRoleRequestType) {
    return new JAXBElement<SearchClientByOrganizationNameAndRoleRequestType>(_SearchClientByOrganizationNameAndRoleRequest_QNAME, SearchClientByOrganizationNameAndRoleRequestType.class, null, paramSearchClientByOrganizationNameAndRoleRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "ClientAssociatedContractOwnersResponse")
  public JAXBElement<ClientRelationshipResponseType> createClientAssociatedContractOwnersResponse(ClientRelationshipResponseType paramClientRelationshipResponseType) {
    return new JAXBElement<ClientRelationshipResponseType>(_ClientAssociatedContractOwnersResponse_QNAME, ClientRelationshipResponseType.class, null, paramClientRelationshipResponseType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "SearchCustomerByProducerIDAndOrganizationNameRequest")
  public JAXBElement<ProducerIdAndNameRequestType> createSearchCustomerByProducerIDAndOrganizationNameRequest(ProducerIdAndNameRequestType paramProducerIdAndNameRequestType) {
    return new JAXBElement<ProducerIdAndNameRequestType>(_SearchCustomerByProducerIDAndOrganizationNameRequest_QNAME, ProducerIdAndNameRequestType.class, null, paramProducerIdAndNameRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "SearchClientByNameAndStateRequest")
  public JAXBElement<SearchClientByNameAndStateRequestType> createSearchClientByNameAndStateRequest(SearchClientByNameAndStateRequestType paramSearchClientByNameAndStateRequestType) {
    return new JAXBElement<SearchClientByNameAndStateRequestType>(_SearchClientByNameAndStateRequest_QNAME, SearchClientByNameAndStateRequestType.class, null, paramSearchClientByNameAndStateRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "SearchClientByNameAndDOBRequest")
  public JAXBElement<SearchClientByNameAndDOBRequestType> createSearchClientByNameAndDOBRequest(SearchClientByNameAndDOBRequestType paramSearchClientByNameAndDOBRequestType) {
    return new JAXBElement<SearchClientByNameAndDOBRequestType>(_SearchClientByNameAndDOBRequest_QNAME, SearchClientByNameAndDOBRequestType.class, null, paramSearchClientByNameAndDOBRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "SearchCustomerByProducerIDAndGovernmentIDAndOrganizationNameRequest")
  public JAXBElement<ProducerIdAndNameAndGovernmentIdRequestType> createSearchCustomerByProducerIDAndGovernmentIDAndOrganizationNameRequest(ProducerIdAndNameAndGovernmentIdRequestType paramProducerIdAndNameAndGovernmentIdRequestType) {
    return new JAXBElement<ProducerIdAndNameAndGovernmentIdRequestType>(_SearchCustomerByProducerIDAndGovernmentIDAndOrganizationNameRequest_QNAME, ProducerIdAndNameAndGovernmentIdRequestType.class, null, paramProducerIdAndNameAndGovernmentIdRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "SearchClientByEmailAddressAndNameRequest")
  public JAXBElement<EmailAddressAndNameRequestType> createSearchClientByEmailAddressAndNameRequest(EmailAddressAndNameRequestType paramEmailAddressAndNameRequestType) {
    return new JAXBElement<EmailAddressAndNameRequestType>(_SearchClientByEmailAddressAndNameRequest_QNAME, EmailAddressAndNameRequestType.class, null, paramEmailAddressAndNameRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "SearchClientByGovtIDAndDOBRequest")
  public JAXBElement<SearchClientByGovtIDAndDOBRequestType> createSearchClientByGovtIDAndDOBRequest(SearchClientByGovtIDAndDOBRequestType paramSearchClientByGovtIDAndDOBRequestType) {
    return new JAXBElement<SearchClientByGovtIDAndDOBRequestType>(_SearchClientByGovtIDAndDOBRequest_QNAME, SearchClientByGovtIDAndDOBRequestType.class, null, paramSearchClientByGovtIDAndDOBRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "SearchClientByOrganizationNameRequest")
  public JAXBElement<SearchClientByOrganizationNameRequestType> createSearchClientByOrganizationNameRequest(SearchClientByOrganizationNameRequestType paramSearchClientByOrganizationNameRequestType) {
    return new JAXBElement<SearchClientByOrganizationNameRequestType>(_SearchClientByOrganizationNameRequest_QNAME, SearchClientByOrganizationNameRequestType.class, null, paramSearchClientByOrganizationNameRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "ClientProfileResponse")
  public JAXBElement<ClientProfileResponseType> createClientProfileResponse(ClientProfileResponseType paramClientProfileResponseType) {
    return new JAXBElement<ClientProfileResponseType>(_ClientProfileResponse_QNAME, ClientProfileResponseType.class, null, paramClientProfileResponseType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "RetrieveAllClientReturnedMailRequest")
  public JAXBElement<ClientIdRequestType> createRetrieveAllClientReturnedMailRequest(ClientIdRequestType paramClientIdRequestType) {
    return new JAXBElement<ClientIdRequestType>(_RetrieveAllClientReturnedMailRequest_QNAME, ClientIdRequestType.class, null, paramClientIdRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "RetrieveClientReturnedMailIndicatorRequest")
  public JAXBElement<ClientIdRequestType> createRetrieveClientReturnedMailIndicatorRequest(ClientIdRequestType paramClientIdRequestType) {
    return new JAXBElement<ClientIdRequestType>(_RetrieveClientReturnedMailIndicatorRequest_QNAME, ClientIdRequestType.class, null, paramClientIdRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "SearchClientByOrganizationNameAndStateRequest")
  public JAXBElement<SearchClientByOrganizationNameAndStateRequestType> createSearchClientByOrganizationNameAndStateRequest(SearchClientByOrganizationNameAndStateRequestType paramSearchClientByOrganizationNameAndStateRequestType) {
    return new JAXBElement<SearchClientByOrganizationNameAndStateRequestType>(_SearchClientByOrganizationNameAndStateRequest_QNAME, SearchClientByOrganizationNameAndStateRequestType.class, null, paramSearchClientByOrganizationNameAndStateRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "ClientUnclaimedMailResponse")
  public JAXBElement<ClientUnclaimedMailResponseType> createClientUnclaimedMailResponse(ClientUnclaimedMailResponseType paramClientUnclaimedMailResponseType) {
    return new JAXBElement<ClientUnclaimedMailResponseType>(_ClientUnclaimedMailResponse_QNAME, ClientUnclaimedMailResponseType.class, null, paramClientUnclaimedMailResponseType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "SearchClientByGovtIDAndOrganizationNameRequest")
  public JAXBElement<SearchClientByGovtIDAndOrganizationNameRequestType> createSearchClientByGovtIDAndOrganizationNameRequest(SearchClientByGovtIDAndOrganizationNameRequestType paramSearchClientByGovtIDAndOrganizationNameRequestType) {
    return new JAXBElement<SearchClientByGovtIDAndOrganizationNameRequestType>(_SearchClientByGovtIDAndOrganizationNameRequest_QNAME, SearchClientByGovtIDAndOrganizationNameRequestType.class, null, paramSearchClientByGovtIDAndOrganizationNameRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "ChangeClientReturnedMailIndicatorRequest")
  public JAXBElement<ChangeClientReturnedMailIndicatorRequestType> createChangeClientReturnedMailIndicatorRequest(ChangeClientReturnedMailIndicatorRequestType paramChangeClientReturnedMailIndicatorRequestType) {
    return new JAXBElement<ChangeClientReturnedMailIndicatorRequestType>(_ChangeClientReturnedMailIndicatorRequest_QNAME, ChangeClientReturnedMailIndicatorRequestType.class, null, paramChangeClientReturnedMailIndicatorRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "SearchClientByNameRequest")
  public JAXBElement<SearchClientByNameRequestType> createSearchClientByNameRequest(SearchClientByNameRequestType paramSearchClientByNameRequestType) {
    return new JAXBElement<SearchClientByNameRequestType>(_SearchClientByNameRequest_QNAME, SearchClientByNameRequestType.class, null, paramSearchClientByNameRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "SearchCustomerByProducerIDAndGovernmentIDRequest")
  public JAXBElement<ProducerIdAndGovernmentIdRequestType> createSearchCustomerByProducerIDAndGovernmentIDRequest(ProducerIdAndGovernmentIdRequestType paramProducerIdAndGovernmentIdRequestType) {
    return new JAXBElement<ProducerIdAndGovernmentIdRequestType>(_SearchCustomerByProducerIDAndGovernmentIDRequest_QNAME, ProducerIdAndGovernmentIdRequestType.class, null, paramProducerIdAndGovernmentIdRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "SearchClientByOrganizationNameAndPhoneRequest")
  public JAXBElement<SearchClientByOrganizationNameAndPhoneRequestType> createSearchClientByOrganizationNameAndPhoneRequest(SearchClientByOrganizationNameAndPhoneRequestType paramSearchClientByOrganizationNameAndPhoneRequestType) {
    return new JAXBElement<SearchClientByOrganizationNameAndPhoneRequestType>(_SearchClientByOrganizationNameAndPhoneRequest_QNAME, SearchClientByOrganizationNameAndPhoneRequestType.class, null, paramSearchClientByOrganizationNameAndPhoneRequestType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", name = "RetrieveClientAssociatedContractOwnersRequest")
  public JAXBElement<ClientIdRequestType> createRetrieveClientAssociatedContractOwnersRequest(ClientIdRequestType paramClientIdRequestType) {
    return new JAXBElement<ClientIdRequestType>(_RetrieveClientAssociatedContractOwnersRequest_QNAME, ClientIdRequestType.class, null, paramClientIdRequestType);
  }
}
