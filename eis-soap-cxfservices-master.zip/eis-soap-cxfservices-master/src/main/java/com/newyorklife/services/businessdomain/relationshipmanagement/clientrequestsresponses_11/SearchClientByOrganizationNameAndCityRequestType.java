package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.schemas.framework.searchbaserequest_2.SearchBaseRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.OrganizationNameAndCityAdType;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SearchClientByOrganizationNameAndCityRequestType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"clientOrganizationNameAndCity"})
public class SearchClientByOrganizationNameAndCityRequestType extends SearchBaseRequestType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "ClientOrganizationNameAndCity")
  protected List<OrganizationNameAndCityAdType> clientOrganizationNameAndCity;
  
  public List<OrganizationNameAndCityAdType> getClientOrganizationNameAndCity() {
    if (this.clientOrganizationNameAndCity == null)
      this.clientOrganizationNameAndCity = new ArrayList<OrganizationNameAndCityAdType>(); 
    return this.clientOrganizationNameAndCity;
  }
}
