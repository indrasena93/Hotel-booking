package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.schemas.cim.contactinformation.phonenumber_5.PhoneNumberType;
import com.newyorklife.schemas.framework.searchbaserequest_2.SearchBaseRequestType;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SearchClientByPhoneRequestType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"phoneNumber"})
public class SearchClientByPhoneRequestType extends SearchBaseRequestType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "PhoneNumber")
  protected List<PhoneNumberType> phoneNumber;
  
  public List<PhoneNumberType> getPhoneNumber() {
    if (this.phoneNumber == null)
      this.phoneNumber = new ArrayList<PhoneNumberType>(); 
    return this.phoneNumber;
  }
}
