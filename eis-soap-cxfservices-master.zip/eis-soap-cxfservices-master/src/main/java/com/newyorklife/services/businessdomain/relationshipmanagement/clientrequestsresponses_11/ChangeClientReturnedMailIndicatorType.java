package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.schemas.cim.common.codetype_1.CodeType;
import com.newyorklife.schemas.cim.financialcontract.contract_5.ContractType;
import java.io.Serializable;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ChangeClientReturnedMailIndicatorType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"clientId", "contract", "clientRoleCd", "unclaimedMailIn"})
public class ChangeClientReturnedMailIndicatorType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "ClientId")
  protected String clientId;
  
  @XmlElement(name = "Contract")
  protected ContractType contract;
  
  @XmlElement(name = "ClientRoleCd")
  protected CodeType clientRoleCd;
  
  @XmlElement(name = "UnclaimedMailIn")
  protected Boolean unclaimedMailIn;
  
  public String getClientId() {
    return this.clientId;
  }
  
  public void setClientId(String paramString) {
    this.clientId = paramString;
  }
  
  public ContractType getContract() {
    return this.contract;
  }
  
  public void setContract(ContractType paramContractType) {
    this.contract = paramContractType;
  }
  
  public CodeType getClientRoleCd() {
    return this.clientRoleCd;
  }
  
  public void setClientRoleCd(CodeType paramCodeType) {
    this.clientRoleCd = paramCodeType;
  }
  
  public Boolean isUnclaimedMailIn() {
    return this.unclaimedMailIn;
  }
  
  public void setUnclaimedMailIn(Boolean paramBoolean) {
    this.unclaimedMailIn = paramBoolean;
  }
}
