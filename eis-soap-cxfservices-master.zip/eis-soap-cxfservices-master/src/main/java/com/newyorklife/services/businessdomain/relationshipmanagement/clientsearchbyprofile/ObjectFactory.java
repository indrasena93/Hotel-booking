package com.newyorklife.services.businessdomain.relationshipmanagement.clientsearchbyprofile;

import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.ClientProfileResponseType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.SearchClientByProfileUsingWeightsRequestType;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

@XmlRegistry
public class ObjectFactory {
  private static final QName _SearchClientByProfileUsingWeightsResponse_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientsearchbyprofile", "SearchClientByProfileUsingWeightsResponse");
  
  private static final QName _SearchClientByProfileUsingWeightsRequest_QNAME = new QName("http://newyorklife.com/services/businessdomain/relationshipmanagement/clientsearchbyprofile", "SearchClientByProfileUsingWeightsRequest");
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientsearchbyprofile", name = "SearchClientByProfileUsingWeightsResponse")
  public JAXBElement<ClientProfileResponseType> createSearchClientByProfileUsingWeightsResponse(ClientProfileResponseType paramClientProfileResponseType) {
    return new JAXBElement<ClientProfileResponseType>(_SearchClientByProfileUsingWeightsResponse_QNAME, ClientProfileResponseType.class, null, paramClientProfileResponseType);
  }
  
  @XmlElementDecl(namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientsearchbyprofile", name = "SearchClientByProfileUsingWeightsRequest")
  public JAXBElement<SearchClientByProfileUsingWeightsRequestType> createSearchClientByProfileUsingWeightsRequest(SearchClientByProfileUsingWeightsRequestType paramSearchClientByProfileUsingWeightsRequestType) {
    return new JAXBElement<SearchClientByProfileUsingWeightsRequestType>(_SearchClientByProfileUsingWeightsRequest_QNAME, SearchClientByProfileUsingWeightsRequestType.class, null, paramSearchClientByProfileUsingWeightsRequestType);
  }
}
