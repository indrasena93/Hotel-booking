package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.schemas.framework.searchbaserequest_2.SearchBaseRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.GovtIDAndOrganizationNameType;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SearchClientByGovtIDAndOrganizationNameRequestType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"clientGovtIDAndOrganizationName"})
public class SearchClientByGovtIDAndOrganizationNameRequestType extends SearchBaseRequestType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "ClientGovtIDAndOrganizationName")
  protected List<GovtIDAndOrganizationNameType> clientGovtIDAndOrganizationName;
  
  public List<GovtIDAndOrganizationNameType> getClientGovtIDAndOrganizationName() {
    if (this.clientGovtIDAndOrganizationName == null)
      this.clientGovtIDAndOrganizationName = new ArrayList<GovtIDAndOrganizationNameType>(); 
    return this.clientGovtIDAndOrganizationName;
  }
}
