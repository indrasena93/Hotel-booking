package com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11;

import com.newyorklife.schemas.framework.searchbaserequest_2.SearchBaseRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.NameAndRoleCdType;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SearchClientByNameAndRoleRequestType", namespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/clientrequestsresponses", propOrder = {"clientNameAndRole"})
public class SearchClientByNameAndRoleRequestType extends SearchBaseRequestType implements Serializable {
  private static final long serialVersionUID = -6026937020915831338L;
  
  @XmlElement(name = "ClientNameAndRole")
  protected List<NameAndRoleCdType> clientNameAndRole;
  
  public List<NameAndRoleCdType> getClientNameAndRole() {
    if (this.clientNameAndRole == null)
      this.clientNameAndRole = new ArrayList<NameAndRoleCdType>(); 
    return this.clientNameAndRole;
  }
}
