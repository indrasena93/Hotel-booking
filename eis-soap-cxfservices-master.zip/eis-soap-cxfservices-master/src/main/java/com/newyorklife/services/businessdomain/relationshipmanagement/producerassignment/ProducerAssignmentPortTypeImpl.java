package com.newyorklife.services.businessdomain.relationshipmanagement.producerassignment;

import java.util.List;
import com.newyorklife.services.businessdomain.relationshipmanagement.producerassignment.BusinessException;
import com.newyorklife.services.businessdomain.relationshipmanagement.producerassignment.FatalException;
import com.newyorklife.services.businessdomain.relationshipmanagement.producerassignment.ProducerAssignmentPortType;
import com.newyorklife.services.businessdomain.relationshipmanagement.producerassignment.SystemException;
import com.newyorklife.services.businessdomain.relationshipmanagement.producerrelationshiprequestsresponses_1.AssignProducerByClientIDRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.producerrelationshiprequestsresponses_1.AssignProducerByClientIDResponseType;
import com.newyorklife.services.businessdomain.relationshipmanagement.producerrelationshiprequestsresponses_1.AssignProducerByClientProfileRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.producerrelationshiprequestsresponses_1.AssignProducerByClientProfileResponseType;
import com.newyorklife.webservice.implementation.delegate.ProducerAssignmentDelegate;
//import com.newyorklife.webservice.dto.ConsumerContractProducerProfile;
import com.nyl.ed.consumer.ConsumerContractProducerProfile;
import com.newyorklife.webservice.datamap.ClientDataMap;
import com.newyorklife.webservice.dao.impl.ConsumerDAO;
import com.newyorklife.schemas.framework.status_1.StatusType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.jws.WebService;

@WebService(serviceName = "ProducerAssignmentService", portName = "ProducerAssignmentPort", targetNamespace = "http://newyorklife.com/services/businessdomain/relationshipmanagement/producerassignment", endpointInterface = "com.newyorklife.services.businessdomain.relationshipmanagement.producerassignment.ProducerAssignmentPortType")
public class ProducerAssignmentPortTypeImpl implements ProducerAssignmentPortType {
	private static final Logger log = LoggerFactory.getLogger(ProducerAssignmentPortTypeImpl.class);
  
  public AssignProducerByClientIDResponseType assignProducerByClientID(AssignProducerByClientIDRequestType paramAssignProducerByClientIDRequestType) throws BusinessException, FatalException, SystemException {
	  log.info("Executing operation assignProducerByClientID");
    try {
    	
      return ProducerAssignmentDelegate.assignProducerByClientID(paramAssignProducerByClientIDRequestType);
    } catch (Exception exception) {
      exception.printStackTrace();
      throw new RuntimeException(exception);
    } 
  }
  
  public AssignProducerByClientProfileResponseType assignProducerByClientProfile(AssignProducerByClientProfileRequestType paramAssignProducerByClientProfileRequestType) throws BusinessException, FatalException, SystemException {
	  log.info("Executing operation assignProducerByClientProfile");
	  //log.info("Executing operation assignProducerByClientID"+paramAssignProducerByClientProfileRequestType);
    try {
      return null;
    } catch (Exception exception) {
      exception.printStackTrace();
      throw new RuntimeException(exception);
    } 
  }
}
