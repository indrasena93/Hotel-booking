package com.newyorklife.webservice.implementation.delegate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.newyorklife.schemas.framework.status_1.StatusType;
import com.newyorklife.services.businessdomain.relationshipmanagement.producerrelationshiprequestsresponses_1.AssignProducerByClientIDRequestType;
import com.newyorklife.services.businessdomain.relationshipmanagement.producerrelationshiprequestsresponses_1.AssignProducerByClientIDResponseType;
import com.newyorklife.services.businessdomain.relationshipmanagement.producerassignment.ProducerAssignmentPortTypeImpl;
import com.newyorklife.webservice.dao.impl.ConsumerDAO;
import com.newyorklife.webservice.datamap.ClientDataMap;
import com.nyl.frameworks.util.NylException;
import com.nyl.frameworks.util.NylNotFoundException;
import com.newyorklife.services.businessdomain.relationshipmanagement.producerassignment.BusinessException;
import com.newyorklife.services.businessdomain.relationshipmanagement.producerassignment.FatalException;
import com.newyorklife.services.businessdomain.relationshipmanagement.producerassignment.SystemException;

public class ProducerAssignmentDelegate {
	private static final Logger log = LoggerFactory.getLogger(ProducerAssignmentDelegate.class);
	  
  public static AssignProducerByClientIDResponseType assignProducerByClientID(AssignProducerByClientIDRequestType paramAssignProducerByClientIDRequestType) throws NylNotFoundException, NylException {
	 
    AssignProducerByClientIDResponseType assignProducerByClientIDResponseType = new AssignProducerByClientIDResponseType();
    assignProducerByClientIDResponseType.setStatusCd(StatusType.SUCCESS);
    assignProducerByClientIDResponseType.setRequest(paramAssignProducerByClientIDRequestType);
     for (byte b = 0; b < paramAssignProducerByClientIDRequestType.getClientId().size(); b++) {
      try {
        assignProducerByClientIDResponseType.getProducerProfileAndStatusType().add(ClientDataMap.mapProducerProfileAndStatus(ConsumerDAO.getConsumerContractProducerProfiles(paramAssignProducerByClientIDRequestType.getClientId().get(b)), "SUCCESS"));
      } catch (NylNotFoundException nylNotFoundException) {
        assignProducerByClientIDResponseType.getProducerProfileAndStatusType().add(ClientDataMap.mapProducerProfileAndStatus(null, "NO_DATA_FOUND"));
      } catch (NylException nylException) {
        assignProducerByClientIDResponseType.getProducerProfileAndStatusType().add(ClientDataMap.mapProducerProfileAndStatus(null, "FAILURE"));
      } 
    } 
    return assignProducerByClientIDResponseType;
  }
}
