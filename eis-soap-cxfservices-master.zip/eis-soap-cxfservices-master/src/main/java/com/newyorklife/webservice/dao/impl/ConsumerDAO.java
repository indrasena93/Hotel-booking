package com.newyorklife.webservice.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;

import com.newyorklife.webservice.dao.config.DBConfig;
import com.newyorklife.webservice.dao.config.OracleDSConfig;
import com.newyorklife.utils.WSConstants;
import com.newyorklife.admin.WSApplicationContext;

import com.nyl.ed.consumer.ConsumerContractProducerProfile;
import com.nyl.dao.consumer.ConsumerMatchCriteria;
import com.nyl.dao.consumer.ConsumerMatchProperties;
import com.nyl.dao.consumer.ConsumerMatchUtil;
import com.nyl.dao.consumer.ConsumerMatchWeights;
import com.nyl.ed.consumer.Address;
import com.nyl.frameworks.datatype.NYLAmount;
import com.nyl.frameworks.datatype.NYLDate;
import com.nyl.frameworks.util.NYLStringUtility;
import com.nyl.frameworks.util.NylContext;
import com.nyl.frameworks.util.NylException;
import com.nyl.frameworks.util.NylNotFoundException;

public class ConsumerDAO implements WSConstants {

	private static final Logger log = LoggerFactory.getLogger(ConsumerDAO.class);
	private static DBConfig dbCfg;
	private static final String INDIVIDUAL = "I";

	public static DataSource getDataSource() {
		DataSource dataSource = null;
		dbCfg = new OracleDSConfig();

		try {
			dataSource = dbCfg.getDataSource(WSConstants.DATA_SOURCE);

		} catch (Exception e) {

		}

		return dataSource;
	}

	public static String getMatchingConsumer(String lastNm, String firstNm, NYLDate birthDt, String taxId,
			Address address, ConsumerMatchProperties props) throws NylNotFoundException, NylException {
		// ConsumerUtilityAccess consumerUtilityAccess
		// =ConsumerUtilityAccess.getInstance();
		// return consumerUtilityAccess.getMatchingConsumer(null,
		// paramString1,paramString2, paramNYLDate, paramString3,
		// paramAddress, paramConsumerMatchProperties);
		log.info("Start ConsumerDAO getMatchingConsumer ...");
		checkArgLastName(lastNm);
		DataSource dataSource = null;
		Connection conn = null;
		String clientId = null;
		try {
			dataSource = getDataSource();
			conn = dataSource.getConnection();
			// get ConsumerContractProducerProfiles, get datasource from DB
			clientId = getMatchingConsumer(conn, lastNm, firstNm, birthDt, taxId, address, props);
			log.info("Successfully get MatchingConsumer From DB");
			checkResults(clientId, "No Matching ConsumerID found");
		} catch (NylNotFoundException e) {
			e.printStackTrace();
			throw e;
		} catch (SQLException e) {
			e.printStackTrace();
			log.error("Failed to getMatchingConsumer on DB for errCode={}, errMsg={}", e.getErrorCode(),
					e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Failed to getMatchingConsumer on DB for errMsg={}", e.getMessage());

		} finally {
			if (conn != null) {
			}
			dbCfg.dsClose(conn);
		}
		checkClientId(clientId);
		return clientId;
	}

	protected static void checkResults(String clientId, String msg) throws NylNotFoundException {
		if (clientId == null || clientId.equals(""))
			throw new NylNotFoundException(msg);
	}

	protected static void checkResults(List results, String msg) throws NylNotFoundException {
		if (isListEmpty(results))
			throw new NylNotFoundException(msg);
	}

	protected static void checkClientId(String clientId) throws NylException {
		if (clientId == null)
			throw new NylException("Response ClienId can't be null");
	}

//	protected void checkArgConsumerId(String consumerId) throws IllegalArgumentException {
//		Assert.hasText(consumerId, "A consumer id is required");
//	}

	protected static void checkArgConsumerId(String clientId) throws NylException {
		if (clientId == null || clientId.equals("") || clientId.trim().equals("")) {
			throw new NylException("A clientId id is required");
		}
	}

//	private static void checkArgLastName(String lastNm) {
//		Assert.hasText(lastNm, "A last name must be supplied");
//	}

	private static void checkArgLastName(String lastNm) throws NylException {
		if (lastNm == null || lastNm.equals("") || lastNm.trim().equals("")) {
			throw new NylException("A last name must be supplied");
		}
	}

	private static String removeSuffix(String theLastName, ConsumerMatchProperties props) {
		int i = theLastName.lastIndexOf(' ');
		if (i < 0)
			return theLastName;
		else {
			String sfx = null;

			// If there is a . (period) at the end of the name, remove it
			int lastPos = theLastName.length() - 1;
			if (theLastName.charAt(lastPos) == '.')
				sfx = theLastName.substring(i + 1, lastPos);
			else
				sfx = theLastName.substring(i + 1);

			String[] suffixRemovalList = props.getPropertyArray("SUFFIX_REMOVAL_LIST");

			for (int j = 0; j < suffixRemovalList.length; j++)
				if (suffixRemovalList[j].equals(sfx))
					return theLastName.substring(0, i);

			return theLastName;
		}
	}

	public static String getMatchingConsumer(Connection conn, String lastNm, String firstNm, NYLDate birthDt,
			String taxId, Address address, ConsumerMatchProperties props)
			throws NylNotFoundException, NylException, SQLException, Exception {
		// checkArgLastName(lastNm);
		// Set up the criteria based upon the arguments
		boolean nullFirstNm = NYLStringUtility.isEmpty(firstNm);
		ConsumerMatchCriteria criteria = new ConsumerMatchCriteria();
		lastNm = lastNm.toUpperCase();
		criteria.setLastNm((nullFirstNm ? lastNm.trim() : removeSuffix(lastNm, props).trim()));
		criteria.setFirstNm(nullFirstNm ? null : firstNm.trim());
		criteria.setAddressLine(address != null ? address.getLine1Ad() : null);
		if (NYLStringUtility.isEmpty(criteria.getAddressLine()))
			criteria.setAddressLine(null);
		criteria.setCity(
				address == null ? null : (NYLStringUtility.isEmpty(address.getCityAd()) ? null : address.getCityAd()));
		criteria.setState(address == null ? null
				: (NYLStringUtility.isEmpty(address.getStateCd()) ? null : address.getStateCd()));
		criteria.setTaxId(NYLStringUtility.isEmpty(taxId) ? null : taxId.trim());
		criteria.setBirthDt(birthDt);
		log.info("getMatchingConsumersByName start");
		log.info("CALLOUTENTRY");
		List<ConsumerMatchCriteria> results = getMatchingConsumersByName(conn, criteria);
		log.info("CALLOUTEXIT");
		log.info("getMatchingConsumersByName end");
		int i = results.size();
		return getMatchingConsumerUsingWeights(conn, results, criteria, props.getTHRESHOLD_MATCHING(),
				props.getTHRESHOLD_MATCHING_ORG(), props);
		// List results = queryForList("get-matching-consumers-by-name", criteria);
		// return getMatchingConsumerUsingWeights(results, criteria,
		// props.getTHRESHOLD_MATCHING(), props.getTHRESHOLD_MATCHING_ORG(), props);
	}

	private static ConsumerMatchWeights getWeights(String prefix, ConsumerMatchProperties props) {
		ConsumerMatchWeights weights = new ConsumerMatchWeights(prefix);
		weights.setEqu(props.getPropertyInt(prefix + "_EQU", 0));
		weights.setTru(props.getPropertyInt(prefix + "_TRU", 0));
		weights.setAlt(props.getPropertyInt(prefix + "_ALT", 0));
		weights.setIns(props.getPropertyInt(prefix + "_INS", 0));
		weights.setTrn(props.getPropertyInt(prefix + "_TRN", 0));
		weights.setNeq(props.getPropertyInt(prefix + "_NEQ", 0));
		weights.setMci(props.getPropertyInt(prefix + "_MCI", 0));
		return weights;
	}

	private static String removeSpecialChar(String strVal, ConsumerMatchProperties props) {
		if (NYLStringUtility.isEmpty(strVal))
			return strVal;

		int strLength = strVal.length();
		char[] charArray = new char[strLength];

		int j = 0;
		for (int i = 0; i < strLength; i++) {
			if (props.getSPECIAL_CHARACTERS().indexOf(strVal.charAt(i)) < 0) {
				charArray[j] = strVal.charAt(i);
				j++;
			}
		}
		return (new String(charArray)).trim();
	}

	public static boolean isListEmpty(List results) {
		if (results != null && results.size() > 0)
			return false;
		return true;
	}

	private static String getMatchingConsumerUsingWeights(Connection conn, List<ConsumerMatchCriteria> results,
			ConsumerMatchCriteria criteria, int thresholdPerson, int thresholdOrg, ConsumerMatchProperties props)
			throws NylNotFoundException, NylException, SQLException, Exception {
		
		log.info("getMatchingConsumerUsingWeights start");

		boolean nullFirstNm = NYLStringUtility.isEmpty(criteria.getFirstNm());
		int threshold = ((nullFirstNm) ? thresholdOrg : thresholdPerson);
		int weight = 0, lastNmWt = 0, firstNmWt = 0, fullNmWt = 0, dobWt = 0, taxWt = 0, maxTaxWt = 0, maxWeight = 0;
		int addressWt, maxAddressWt = 0;
		String matchingClientId = null;
		String lastClientId = "";

		if (!isListEmpty(results)) {
			log.info("fetchTINsWithClId start");
			log.info("CALLOUTENTRY");
			ArrayList<ClientTaxId> tinsWithClId = fetchTINsWithClId(conn,criteria);
			log.info("CALLOUTEXIT");
			log.info("fetchTINsWithClId end");
			log.info("fetchAddressFromClId start");
			log.info("CALLOUTENTRY");
			ArrayList<ClientAddress> addressWithClId = fetchAddressFromClId(conn,criteria);
			log.info("CALLOUTEXIT");
			log.info("fetchAddressFromClId end");
			
			for (Iterator i = results.iterator(); i.hasNext();) {
				ConsumerMatchCriteria result = (ConsumerMatchCriteria) i.next();
				lastNmWt = ConsumerMatchUtil.compareValues(getWeights("LAST_NAME", props),
						removeSpecialChar(criteria.getLastNm(), props), removeSpecialChar(result.getLastNm(), props),
						props.getMAX_TRUNCATION_PC());
				firstNmWt = ConsumerMatchUtil.compareValues(getWeights("FIRST_NAME", props),
						removeSpecialChar(criteria.getFirstNm(), props), removeSpecialChar(result.getFirstNm(), props),
						props.getMAX_TRUNCATION_PC());

				if (criteria.getBirthDt() != null && result.getBirthDt() != null)
					dobWt = ConsumerMatchUtil.compareValues(getWeights("BIRTH_DATE", props),
							criteria.getBirthDt().toString(), result.getBirthDt().toString(),
							props.getMAX_TRUNCATION_PC(), true);

				lastClientId = result.getClientId();
				maxTaxWt = 0;
				maxAddressWt = 0;

				if (criteria.getTaxId() != null) {
					// List resultsTaxId = queryForList("get-matching-tax-id",
					// result.getClientId());
					List<String> resultsTaxId = getMatchingTaxId2(result.getClientId(),tinsWithClId);
					String foundTaxId = (isListEmpty(resultsTaxId) ? "" : (String) resultsTaxId.get(0));
					taxWt = ConsumerMatchUtil.compareValues(getWeights("TAX_ID", props), criteria.getTaxId(),
							foundTaxId.trim(), props.getMAX_TRUNCATION_PC(), true);
					if (taxWt > maxTaxWt)
						maxTaxWt = taxWt;
				}

				if (criteria.getAddressLine() != null) {
					// List foundAddressList = (List)queryForList("get-matching-addresses",
					// result.getClientId());
					List<Address> foundAddressList = getMatchingAddresses2(result.getClientId(), addressWithClId);
					if (!isListEmpty(foundAddressList))
						for (Iterator k = foundAddressList.iterator(); k.hasNext();) {
							Address foundAddress = (Address) k.next();
							addressWt = ConsumerMatchUtil.compareValues(getWeights("STREET_ADDR1", props),
									criteria.getAddressLine(), foundAddress.getLine1Ad(), props.getMAX_TRUNCATION_PC(),
									true);

							if (props.isShouldCheckCityState() && criteria.getCity() != null
									&& criteria.getState() != null) {
								addressWt += ConsumerMatchUtil.compareValues(getWeights("CITY_STATE", props),
										criteria.getCity() + criteria.getState(),
										foundAddress.getCityAd() + foundAddress.getStateCd(),
										props.getMAX_TRUNCATION_PC(), true);
							}

							if (addressWt > maxAddressWt)
								maxAddressWt = addressWt;
						}
				}

				// Total name weight is negative, but there is some match on other criteria
				if ((firstNmWt + lastNmWt) < 0 && (dobWt > 0 || maxTaxWt > 0 || maxAddressWt > 0)) {
					String thisFullNm = criteria.getLastNm() + criteria.getFirstNm();
					if (INDIVIDUAL.equals(result.getTypeCd()))
						thisFullNm = criteria.getFirstNm() + criteria.getLastNm();
					fullNmWt = ConsumerMatchUtil.compareValues(getWeights("FULL_NAME", props),
							removeSpecialChar(thisFullNm, props), removeSpecialChar(result.getFullNm(), props),
							props.getMAX_TRUNCATION_PC(), false);
					if (fullNmWt > getWeights("FIRST_NAME", props).getTru()) {
						firstNmWt = fullNmWt;
						lastNmWt = 0;
					}
				}

				weight = lastNmWt + firstNmWt + dobWt + maxTaxWt + maxAddressWt;

				if (weight > maxWeight) {
					maxWeight = weight;
					matchingClientId = result.getClientId();
				}
			}
		}

		if (maxWeight >= threshold) {
			log.info("getMatchingConsumerUsingWeights ends");
			return matchingClientId;
		}
			
		else
			throw new NylNotFoundException("No matching client found using criteria: " + criteria.toString());
	}

	private static ArrayList<ClientTaxId> fetchTINsWithClId(Connection conn,ConsumerMatchCriteria criteria) throws SQLException {
		String firstNameCondition="";
		PreparedStatement preStm = null;
		boolean shouldAddFNLike = (criteria.getFirstNm() != null);
		if (shouldAddFNLike) {
			firstNameCondition = " and n.FST_NM like ? ";
		}
		
		String queryString = "select  distinct CL_ID,TIN\r\n"
				+ "			\r\n"
				+ "		from\r\n"
				+ "			co0101.CL_TX_ID\r\n"
				+ "		where\r\n"
				+ "			CL_ID in (select distinct\r\n"
				+ "			n.CL_ID\r\n"
				+ "			\r\n"
				+ "		from\r\n"
				+ "			co0101.CLIENT_NAME n where \r\n"
				+ "\t    n.LST_NM like ? " +firstNameCondition+ ")";
		
		preStm = conn.prepareStatement(queryString);
		preStm.setFetchSize(2000);
		preStm.setString(1, criteria.getLastNmLike());
		if(shouldAddFNLike) {
			preStm.setString(2, criteria.getFirstInitialLike());
		}
		ResultSet retObj = preStm.executeQuery();
		ArrayList<ClientTaxId> clIdTaxIdArrayList = new ArrayList<>();
		ClientTaxId clientTaxId = null;
		log.info("fetchTINsWithClId while start");
		while (retObj.next()) {
			clientTaxId = new ClientTaxId(retObj.getString("CL_ID"), retObj.getString("TIN"));
			clIdTaxIdArrayList.add(clientTaxId);
			}
		log.info("fetchTINsWithClId while end");
		return clIdTaxIdArrayList;
		
	}
	
	private static ArrayList<ClientAddress> fetchAddressFromClId(Connection conn,ConsumerMatchCriteria criteria) throws SQLException {
		String firstNameCondition="";
		PreparedStatement preStm = null;
		boolean shouldAddFNLike = (criteria.getFirstNm() != null);
		if (shouldAddFNLike) {
			firstNameCondition = " and n.FST_NM like ? ";
		}
		
		String queryString = "select \r\n"
				+ "			CL_Id,STR_ONE_AD, CTY_AD, STATE_CD\r\n"
				+ "		from\r\n"
				+ "			co0101.ADDRESS\r\n"
				+ "		where\r\n"
				+ "			CL_ID in (select distinct\r\n"
				+ "			n.CL_ID\r\n"
				+ "			\r\n"
				+ "		from\r\n"
				+ "			co0101.CLIENT_NAME n where \r\n"
				+ "\t    n.LST_NM like ?" + firstNameCondition + ")";
		
		preStm = conn.prepareStatement(queryString);
		preStm.setFetchSize(2000);
		preStm.setString(1, criteria.getLastNmLike());
		if(shouldAddFNLike) {
			preStm.setString(2, criteria.getFirstInitialLike());
		}
		ResultSet retObj = preStm.executeQuery();
		ArrayList<ClientAddress> clIdAddressArrayList = new ArrayList<>();
		ClientAddress clientAddress = null;
		Address address =null;
		log.info("fetchAddressFromClId while start");
		while (retObj.next()) {
			address = new Address();
			address.setLine1Ad(retObj.getString("STR_ONE_AD"));
			address.setCityAd(retObj.getString("CTY_AD"));
			address.setStateCd(retObj.getString("STATE_CD"));
			clientAddress = new ClientAddress(retObj.getString("CL_ID"),address);
			clIdAddressArrayList.add(clientAddress);
			}
		log.info("fetchAddressFromClId while end");
		return clIdAddressArrayList;
		
	}


	private static List<Address> getMatchingAddresses(Connection conn, String clientId) throws SQLException, Exception {
		PreparedStatement preStm = null;

		String queryString = "select\r\n" + "			STR_ONE_AD,\r\n" + "			CTY_AD,\r\n"
				+ "			STATE_CD\r\n" + "		from\r\n" + "			co0101.ADDRESS\r\n" + "		where\r\n"
				+ "			CL_ID ='" + clientId + "'";

		preStm = conn.prepareStatement(queryString);
		preStm.setFetchSize(2000);
		ResultSet retObj = preStm.executeQuery();
		List<Address> foundAddressList = new ArrayList<>();
		Address address = null;

		while (retObj.next()) {
			address = new Address();
			address.setLine1Ad(retObj.getString("STR_ONE_AD"));
			address.setCityAd(retObj.getString("CTY_AD"));
			address.setStateCd(retObj.getString("STATE_CD"));
			foundAddressList.add(address);
		}
		retObj.close();
		preStm.close();
		return foundAddressList;
	}
	

	private static List<String> getMatchingTaxId(Connection conn, String clientId) throws SQLException, Exception {

		PreparedStatement preStm = null;

		String queryString = "select distinct\r\n" + "			TIN\r\n" + "		from\r\n"
				+ "			co0101.CL_TX_ID\r\n" + "		where\r\n" + "			CL_ID ='" + clientId + "'";

		preStm = conn.prepareStatement(queryString);
		preStm.setFetchSize(2000);
		ResultSet retObj = preStm.executeQuery();
		List<String> resultsTaxId = new ArrayList<>();
		while (retObj.next()) {
			resultsTaxId.add(retObj.getString("TIN"));
		}
		retObj.close();
		preStm.close();
		return resultsTaxId;
	}
	
	private static List<String> getMatchingTaxId2(String clId, ArrayList<ClientTaxId> tinsWithClId) throws SQLException, Exception {

		List<String> resultsTaxId = new ArrayList<>();
		for(ClientTaxId clientTaxId: tinsWithClId) {
			if(clId !=null && clId.equals(clientTaxId.getClientId()) ) {
				resultsTaxId.add(clientTaxId.getTaxId());
			}
		}
		return resultsTaxId;
	}
	
	private static List<Address> getMatchingAddresses2(String clId, ArrayList<ClientAddress> addressWithClId ) throws SQLException, Exception {
		List<Address> foundAddressList = new ArrayList<>();
		Address address = null;

		
		for(ClientAddress addrWithClId: addressWithClId) {
			if(clId !=null && clId.equals(addrWithClId.getClientId()) ) {
				foundAddressList.add(addrWithClId.getAddress());
			}
		}
		
		return foundAddressList;
	}
	
	
	
	private static List<ConsumerMatchCriteria> getMatchingConsumersByName(Connection conn,
			ConsumerMatchCriteria criteria) throws SQLException, Exception {
		PreparedStatement preStm = null;
		String queryString = "select distinct\r\n" + "			n.CL_ID, \r\n"
				+ "			NVL(n.LST_NM,' ') LST_NM, \r\n" + "			NVL(n.FST_NM,' ') FST_NM, \r\n"
				+ "			FL_NM,\r\n" + "			n.BRT_DT, \r\n" + "			n.PRS_ORG_TP_CD as TYP_CD,\r\n"
				+ "			'' as TIN,\r\n" + "			'' as ZIP,\r\n" + "			'' as STR_ONE_AD\r\n"
				+ "		from\r\n" + "			co0101.CLIENT_NAME n where \r\n" + "	    n.LST_NM like '"
				+ criteria.getLastNmLike() + "'";

		if (criteria.getFirstNm() != null) {
			String addFistName = " and n.FST_NM like '" + criteria.getFirstInitialLike() + "' order by n.CL_ID";
			queryString = queryString + addFistName;
		}
		preStm = conn.prepareStatement(queryString);
		preStm.setFetchSize(2000);
		ResultSet retObj = preStm.executeQuery();
		List<ConsumerMatchCriteria> results = new ArrayList<ConsumerMatchCriteria>();
		ConsumerMatchCriteria c = null;
		log.info("getMatchingConsumersByName while start");
		while (retObj.next()) {
			c = new ConsumerMatchCriteria();

			c.setClientId(retObj.getString("CL_ID"));
			c.setLastNm(retObj.getString("LST_NM"));
			c.setFirstNm(retObj.getString("FST_NM"));
			c.setFullNm(retObj.getString("FL_NM"));
			if (retObj.getString("BRT_DT") != null && !retObj.getString("BRT_DT").isEmpty()
					&& !retObj.getString("BRT_DT").trim().isEmpty()) {
				Date date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(retObj.getString("BRT_DT"));
				NYLDate birthDt = new NYLDate(date);
				c.setBirthDt(birthDt);
			}
			c.setTypeCd(retObj.getString("TYP_CD"));
			c.setTaxId(retObj.getString("TIN"));
			c.setPostalCd(retObj.getString("ZIP"));
			c.setAddressLine(retObj.getString("STR_ONE_AD"));

			results.add(c);
		}
		log.info("getMatchingConsumersByName while end");
		retObj.close();
		preStm.close();
		return results;
	}

	public static ConsumerContractProducerProfile[] getConsumerContractProducerProfiles(String clientId)
			throws NylNotFoundException, NylException {
		// ConsumerAccess consumerAccess = ConsumerAccess.getInstance();
		// return consumerAccess.getConsumerContractProducerProfiles(paramString);
		log.info("Start ConsumerDAO getConsumerContractProducerProfiles ...");
		checkArgConsumerId(clientId);

		DataSource dataSource = null;
		Connection conn = null;
		List<ConsumerContractProducerProfile> results = new ArrayList<ConsumerContractProducerProfile>();

		// get data from DB
		try {
			dataSource = getDataSource();
			conn = dataSource.getConnection();
			// get ConsumerContractProducerProfiles, get datasource from DB
			results = getConsumerContractProducerProfilesFromDB(conn, clientId);
			log.info("Successfully get ConsumerContractProducerProfiles From DB");
			checkResults(results, "No ConsumerContractProfiles found for consumer " + clientId);

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("Failed to getConsumerContractProducerProfiles on DB for errCode={}, errMsg={}", e.getErrorCode(),
					e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Failed to getConsumerContractProducerProfiles on DB for errMsg={}", e.getMessage());

		} finally {
			if (conn != null) {
				dbCfg.dsClose(conn);
			}
		}

		return (ConsumerContractProducerProfile[]) results.toArray(new ConsumerContractProducerProfile[results.size()]);
	}

	private static List<ConsumerContractProducerProfile> getConsumerContractProducerProfilesFromDB(Connection conn,
			String clientId) throws SQLException, Exception {
		log.info("Start getConsumerContractProducerProfilesFromDB for clientId={} ...", clientId);
		PreparedStatement preStm = null;

		String queryString = " select \r\n" + "                A.MK_ID as PRODUCER_ID, \r\n"
				+ "                A.MK_RL_CD as PRODUCER_ROLE_CD,\r\n"
				+ "                F.STS_TP_CD as PRODUCER_STATUS_CD,\r\n" + "'" + clientId + "'"
				+ "                 as CLENT_ID,\r\n" + "                A.CNT_ID,\r\n"
				+ "                A.CNT_ISS_CD,\r\n" + "                A.CPN_MK_SPL_PC as SHARE_PC, \r\n"
				+ "                A.LST_UPD_TM\r\n" + "            from \r\n"
				+ "                 cn0101.CTCP_MK_RL A,\r\n" + "                 cn0101.CTCP_MK_RL_TP B, \r\n"
				+ "                 cn0101.CTCP_TP C, \r\n" + "                 cn0101.CONTRACT D, \r\n"
				+ "                 co0101.CONROL E,\r\n" + "                 mkrd01.MK_STATUS_ATV F\r\n"
				+ "            where\r\n" + "                E.CL_ID ='" + clientId + "' and\r\n"
				+ "                A.CNT_ID = E.CNT_ID (+) and \r\n"
				+ "                A.CNT_ISS_CD = E.CNT_ISS_TP_CD (+) and \r\n"
				+ "                A.CNT_ID = D.CNT_ID (+) and \r\n"
				+ "                A.CNT_ISS_CD = D.CNT_ISS_CD (+) and \r\n"
				+ "                A.DAT_SRC_CD = D.DAT_SRC_CD (+) and\r\n"
				+ "                A.DAT_SRC_CD = B.DAT_SRC_CD (+) and \r\n"
				+ "                A.MK_RL_CD = B.MK_RL_CD (+) and \r\n"
				+ "                A.CTCP_CD = C.CTCP_CD (+) and\r\n"
				+ "                A.MK_ID = F.MARKETER_ID and\r\n" + "                F.STS_EDT <= SYSDATE and \r\n"
				+ "			    F.STS_XDT >= SYSDATE\r\n" + "				union      \r\n"
				+ "             select \r\n" + "                A.PRODUCER_ID, \r\n"
				+ "                A.PRODUCER_ROLE_CD,\r\n" + "                F.STS_TP_CD as PRODUCER_STATUS_CD,\r\n"
				+ "'" + clientId + "'" + "                as CLIENT_ID,\r\n" + "                C.CNT_ID,\r\n"
				+ "                C.CNT_ISS_CD,\r\n" + "                A.PRODUCER_ACCOUNT_SHARE_PC as SHARE_PC, \r\n"
				+ "                A.LST_UPD_TM\r\n" + "            from\r\n"
				+ "                cn0101.PRODUCER_ACCOUNT_ROLE A, \r\n" + "                cn0101.ACCOUNT C,\r\n"
				+ "                co0101.CONROL E,\r\n" + "                mkrd01.MK_STATUS_ATV F\r\n"
				+ "            where \r\n" + "                E.CL_ID ='" + clientId + "' and\r\n"
				+ "                C.CNT_ID = E.CNT_ID (+) and \r\n"
				+ "                C.CNT_ISS_CD = E.CNT_ISS_TP_CD (+) and \r\n"
				+ "                C.ACCOUNT_ID = A.ACCOUNT_ID (+) and\r\n"
				+ "                A.PRODUCER_ID = F.MARKETER_ID and\r\n"
				+ "                F.STS_EDT <= SYSDATE and \r\n" + "				F.STS_XDT >= SYSDATE \r\n"
				+ "	         order by CNT_ID \r\n";

		preStm = conn.prepareStatement(queryString);
		ResultSet retObj = preStm.executeQuery();

		List<ConsumerContractProducerProfile> consumerContractProducerProfileList = new ArrayList<ConsumerContractProducerProfile>();
		ConsumerContractProducerProfile ccpProfile = null;

		while (retObj.next()) {
			ccpProfile = new ConsumerContractProducerProfile();

			ccpProfile.setProducerId(retObj.getString("PRODUCER_ID"));
			ccpProfile.setProducerRoleCd(retObj.getString("PRODUCER_ROLE_CD"));
			ccpProfile.setProducerStatusCd(retObj.getString("PRODUCER_STATUS_CD"));
			ccpProfile.setConsumerId(retObj.getString("CLENT_ID"));
			ccpProfile.setContractId(retObj.getString("CNT_ID"));
			ccpProfile.setContractIssueCd(retObj.getString("CNT_ISS_CD"));
			if (retObj.getString("SHARE_PC") != null && !retObj.getString("SHARE_PC").isEmpty()
					&& !retObj.getString("SHARE_PC").trim().isEmpty()) {

				NYLAmount share_pc = new NYLAmount(new BigDecimal(retObj.getString("SHARE_PC")));
				ccpProfile.setSharePc(share_pc);
			}

			if (retObj.getString("LST_UPD_TM") != null && !retObj.getString("LST_UPD_TM").isEmpty()
					&& !retObj.getString("LST_UPD_TM").trim().isEmpty()) {
				Date date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(retObj.getString("LST_UPD_TM"));
				NYLDate lst__upt_tm = new NYLDate(date);
				ccpProfile.setLastUpdatedDt(lst__upt_tm);
			}

			consumerContractProducerProfileList.add(ccpProfile);
		}

		retObj.close();
		preStm.close();

		return consumerContractProducerProfileList;

	}

}

class ClientTaxId {
	private String clientId ="";
	private String taxId = "";
	
	
	
	public String getClientId() {
		return clientId;
	}



	public void setClientId(String clientId) {
		this.clientId = clientId;
	}



	public String getTaxId() {
		return taxId;
	}



	public void setTaxId(String taxId) {
		this.taxId = taxId;
	}



	public ClientTaxId(String clientId,String taxId ) {
		this.clientId = clientId;
		this.taxId = taxId;
	}
	
}

class ClientAddress {
	private String clientId;
	private Address address;
	
	
	
	public String getClientId() {
		return clientId;
	}



	public void setClientId(String clientId) {
		this.clientId = clientId;
	}


	public Address getAddress() {
		return address;
	}



	public void setAddress(Address address) {
		this.address = address;
	}



	public ClientAddress(String clientId, Address address) {
		this.clientId = clientId;
		this.address = address;
	}
	
}
