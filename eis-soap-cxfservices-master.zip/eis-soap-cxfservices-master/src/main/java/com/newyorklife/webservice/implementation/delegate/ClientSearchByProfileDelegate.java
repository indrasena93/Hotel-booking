package com.newyorklife.webservice.implementation.delegate;

import com.newyorklife.schemas.framework.status_1.StatusType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.ClientProfileResponseType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.SearchClientByProfileUsingWeightsRequestType;
import com.newyorklife.webservice.dao.impl.ConsumerDAO;
import com.newyorklife.webservice.datamap.ClientDataMap;
import com.nyl.frameworks.util.NylException;
import com.nyl.frameworks.util.NylNotFoundException;

public class ClientSearchByProfileDelegate {
	public static ClientProfileResponseType searchClientByProfileUsingWeights(
			SearchClientByProfileUsingWeightsRequestType paramSearchClientByProfileUsingWeightsRequestType)
			throws NylNotFoundException, NylException {
		ClientProfileResponseType clientProfileResponseType = new ClientProfileResponseType();
		clientProfileResponseType.setStatusCd(StatusType.SUCCESS);
		clientProfileResponseType.setRequest(paramSearchClientByProfileUsingWeightsRequestType);
		int i = paramSearchClientByProfileUsingWeightsRequestType.getClientProfile().size();
		for (byte b = 0; b < paramSearchClientByProfileUsingWeightsRequestType.getClientProfile().size(); b++) {
			try {
				clientProfileResponseType.getClientProfileStatus().add(ClientDataMap
						.mapClientProfileStatus(ConsumerDAO.getMatchingConsumer(ClientDataMap.mapLowerCaseToUpperCase(
								((SearchClientByProfileUsingWeightsRequestType.ClientProfile) paramSearchClientByProfileUsingWeightsRequestType
										.getClientProfile().get(b)).getLastNm()),
								ClientDataMap.mapLowerCaseToUpperCase(
										((SearchClientByProfileUsingWeightsRequestType.ClientProfile) paramSearchClientByProfileUsingWeightsRequestType
												.getClientProfile().get(b)).getFirstNm()),
								ClientDataMap.mapNYLDate(
										((SearchClientByProfileUsingWeightsRequestType.ClientProfile) paramSearchClientByProfileUsingWeightsRequestType
												.getClientProfile().get(b)).getBirthDt()),
								ClientDataMap.mapLowerCaseToUpperCase(
										((SearchClientByProfileUsingWeightsRequestType.ClientProfile) paramSearchClientByProfileUsingWeightsRequestType
												.getClientProfile().get(b)).getGovernmentTaxId()),
								ClientDataMap.mapAddress(ClientDataMap.mapLowerCaseToUpperCase(
										((SearchClientByProfileUsingWeightsRequestType.ClientProfile) paramSearchClientByProfileUsingWeightsRequestType
												.getClientProfile().get(b)).getCityAd()),
										ClientDataMap.mapLowerCaseToUpperCase(
												((SearchClientByProfileUsingWeightsRequestType.ClientProfile) paramSearchClientByProfileUsingWeightsRequestType
														.getClientProfile().get(b)).getLine1Ad()),
										((SearchClientByProfileUsingWeightsRequestType.ClientProfile) paramSearchClientByProfileUsingWeightsRequestType
												.getClientProfile().get(b)).getPostalCd(),
										((SearchClientByProfileUsingWeightsRequestType.ClientProfile) paramSearchClientByProfileUsingWeightsRequestType
												.getClientProfile().get(b)).getStateCd()),
								ClientDataMap.mapLDSProperty())));
			} catch (NylNotFoundException nylNotFoundException) {
				clientProfileResponseType.getClientProfileStatus()
						.add(ClientDataMap.mapClientProfileStatus("NO_DATA_FOUND"));
			} catch (NylException nylException) {
				clientProfileResponseType.getClientProfileStatus().add(ClientDataMap.mapClientProfileStatus("FAILURE"));
			}
		}
		return clientProfileResponseType;
	}
}
