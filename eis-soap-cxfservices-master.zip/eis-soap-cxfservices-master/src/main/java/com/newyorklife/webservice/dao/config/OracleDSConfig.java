package com.newyorklife.webservice.dao.config;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.newyorklife.admin.WSApplicationContext;
import com.newyorklife.utils.WSConstants;

/**
 *	Author: Chloe Wong		Date: Oct 17, 2014
 */

public class OracleDSConfig implements DBConfig, WSConstants{
	private static final Logger log = LoggerFactory.getLogger(OracleDSConfig.class);
	
	public OracleDSConfig() {
		
	}
	
	public DataSource getDataSource() throws SQLException, Exception{
		
		return (DataSource)WSApplicationContext.getInstance().getApplicationContext().getBean("ORA03DS");
	}
	
	public DataSource getDataSource(String dsId) throws SQLException, Exception{
		
		return (DataSource)WSApplicationContext.getInstance().getApplicationContext().getBean(dsId);
	}
	
	public Connection getConnection() throws SQLException, Exception {
        return getDataSource().getConnection();
    }
    
    public Connection getConnection(String dsName) throws SQLException, Exception {
    	return getDataSource(dsName).getConnection();
    }
    
    public Connection getConnection(String username, String password) throws SQLException, Exception {
        return getDataSource().getConnection(username, password);
    }
    
    public void dsCommit(Connection conn) {
    	try {
    		conn.commit();
    	}catch(SQLException sqle) {
    		log.error("Can not commit datasource, errCode={}, errState={}, errMsg={},", sqle.getErrorCode(), sqle.getSQLState(), sqle.getMessage());
    	}catch(Exception e) {
    		log.error("Can not commit datasource, errMsg={}", e.getMessage());
    	}
    }
    
    public void dsRollBack(Connection conn) {
    	try {
    		conn.rollback();
    	}catch(SQLException sqle) {
    		log.error("Can not rollback datasource, errCode={}, errState={}, errMsg={},", sqle.getErrorCode(), sqle.getSQLState(), sqle.getMessage());
    	}catch(Exception e) {
    		log.error("Can not rollback datasource, errMsg=", e.getMessage());
    	}
    }
    
    public void dsClose(Connection conn) {
    	try {
    		conn.close();
    	}catch(SQLException sqle) {
    		log.error("Can not close datasource, errCode={}, errState={}, errMsg={},", sqle.getErrorCode(), sqle.getSQLState(), sqle.getMessage());
    	}catch(Exception e) {
    		log.error("Can not close datasource, errMsg=", e.getMessage());
    	}
    }

}
