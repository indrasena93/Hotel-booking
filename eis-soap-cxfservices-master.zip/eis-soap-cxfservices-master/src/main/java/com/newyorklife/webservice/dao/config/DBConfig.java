package com.newyorklife.webservice.dao.config;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

/**
 *	Author: Chloe Wong		Date: Jun 20, 2014
 */

public interface DBConfig {
	
	public DataSource getDataSource() throws SQLException, Exception;
	public DataSource getDataSource(String dsName) throws SQLException, Exception;
	public Connection getConnection() throws SQLException, Exception;
	public Connection getConnection(String dsName) throws SQLException, Exception;
	public void dsCommit(Connection conn);
	public void dsRollBack(Connection conn);
	public void dsClose(Connection conn);

}
