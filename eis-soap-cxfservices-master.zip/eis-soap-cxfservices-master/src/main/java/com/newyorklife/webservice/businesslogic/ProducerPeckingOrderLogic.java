package com.newyorklife.webservice.businesslogic;

import com.nyl.ed.consumer.ConsumerContractProducerProfile;
//import com.newyorklife.webservice.dto.ConsumerContractProducerProfile;
import com.nyl.frameworks.datatype.NYLAmount;
import edu.emory.mathcs.backport.java.util.Arrays;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.GregorianCalendar;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;

public class ProducerPeckingOrderLogic {
  private static String[] status = new String[] { "01", "02", "03", "04", "05", "1C" };
  
  private static String[] roles = new String[] { "TA", "PA", "SA", "OA", "AR", "SP", "TA" };
  
  private static String[] invalid_producers = new String[] { "0295875" };
  
  public static String getProducer(ConsumerContractProducerProfile[] paramArrayOfConsumerContractProducerProfile) {
    List list = Arrays.asList((Object[])paramArrayOfConsumerContractProducerProfile);
    ArrayList arrayList = new ArrayList();
    List<ConsumerContractProducerProfile> list1 = getActiveProducers(list);
    if (list1.size() > 0) {
      list1 = applyRoleFilter(list1);
      list1 = applyStatusFilter(list1);
      list1 = applyShareFilter(list1);
      return ((ConsumerContractProducerProfile)list1.get(0)).getProducerId();
    } 
    return null;
  }
  
  private static List getActiveProducers(List paramList) {
    List list1 = Arrays.asList((Object[])status);
    List list2 = Arrays.asList((Object[])invalid_producers);
    ArrayList<ConsumerContractProducerProfile> arrayList = new ArrayList();
    Iterator<ConsumerContractProducerProfile> iterator = paramList.iterator();
    while (iterator.hasNext()) {
      ConsumerContractProducerProfile consumerContractProducerProfile = iterator.next();
      if (consumerContractProducerProfile.getProducerStatusCd() != null && !list2.contains(consumerContractProducerProfile.getProducerId().trim()) && 
        list1.contains(consumerContractProducerProfile.getProducerStatusCd().trim()))
        arrayList.add(consumerContractProducerProfile); 
    } 
    return arrayList;
  }
  
  private static List applyRoleFilter(List<ConsumerContractProducerProfile> paramList) {
    if (paramList.size() == 1)
      return paramList; 
    ArrayList<ConsumerContractProducerProfile> arrayList = new ArrayList();
    for (byte b = 0; b < roles.length; b++) {
      Iterator<ConsumerContractProducerProfile> iterator = paramList.iterator();
      while (iterator.hasNext()) {
        ConsumerContractProducerProfile consumerContractProducerProfile = iterator.next();
        if (b == 0) {
          if (consumerContractProducerProfile.getProducerRoleCd().trim().equals(roles[b])) {
            GregorianCalendar gregorianCalendar1 = new GregorianCalendar();
            GregorianCalendar gregorianCalendar2 = new GregorianCalendar();
            gregorianCalendar1.roll(1, -2);
            gregorianCalendar2.setTime(consumerContractProducerProfile.getLastUpdatedDt().getDate());
            if (gregorianCalendar1.before(gregorianCalendar2))
              arrayList.add(consumerContractProducerProfile); 
          } 
          continue;
        } 
        if (consumerContractProducerProfile.getProducerRoleCd().trim().equals(roles[b]))
          arrayList.add(consumerContractProducerProfile); 
      } 
      if (arrayList.size() > 0)
        break; 
    } 
    if (arrayList.size() == 0)
      arrayList.add(paramList.get(0)); 
    return arrayList;
  }
  
  private static List applyStatusFilter(List paramList) {
    if (paramList.size() == 1)
      return paramList; 
    ArrayList<ConsumerContractProducerProfile> arrayList = new ArrayList();
    for (byte b = 0; b < status.length; b++) {
      Iterator<ConsumerContractProducerProfile> iterator = paramList.iterator();
      while (iterator.hasNext()) {
        ConsumerContractProducerProfile consumerContractProducerProfile = iterator.next();
        if (consumerContractProducerProfile.getProducerStatusCd().trim().equals(status[b]))
          arrayList.add(consumerContractProducerProfile); 
      } 
      if (arrayList.size() > 0)
        break; 
    } 
    return arrayList;
  }
  
  private static List applyShareFilter(List paramList) {
    if (paramList.size() == 1)
      return paramList; 
    ArrayList<ConsumerContractProducerProfile> arrayList1 = new ArrayList();
    ArrayList<ConsumerContractProducerProfile> arrayList2 = new ArrayList();
    Iterator<ConsumerContractProducerProfile> iterator = paramList.iterator();
    while (iterator.hasNext()) {
      ConsumerContractProducerProfile consumerContractProducerProfile = iterator.next();
      if (consumerContractProducerProfile.getSharePc() != null)
        arrayList1.add(consumerContractProducerProfile); 
    } 
    if (arrayList1.size() == 0)
      return paramList; 
    if (arrayList1.size() > 1) {
      Hashtable<Object, Object> hashtable = new Hashtable<Object, Object>();
      Iterator<ConsumerContractProducerProfile> iterator1 = arrayList1.iterator();
      while (iterator1.hasNext()) {
        ConsumerContractProducerProfile consumerContractProducerProfile = iterator1.next();
        String str = consumerContractProducerProfile.getProducerId();
        if (hashtable.containsKey(str)) {
          ConsumerContractProducerProfile consumerContractProducerProfile1 = (ConsumerContractProducerProfile)hashtable.get(str);
          NYLAmount nYLAmount1 = consumerContractProducerProfile1.getSharePc();
          NYLAmount nYLAmount2 = consumerContractProducerProfile.getSharePc();
          NYLAmount nYLAmount3 = new NYLAmount(nYLAmount1.getAmount().add(nYLAmount2.getAmount()));
          consumerContractProducerProfile1.setSharePc(nYLAmount3);
          continue;
        } 
        hashtable.put(str, consumerContractProducerProfile);
      } 
      Enumeration enumeration = hashtable.keys();
      while (enumeration.hasMoreElements())
        arrayList2.add((ConsumerContractProducerProfile)hashtable.get(enumeration.nextElement())); 
    } 
    if (arrayList2.size() == 1)
      return arrayList2; 
    Collections.sort(arrayList2, (Comparator<? super ConsumerContractProducerProfile>)new Object());
    return arrayList2;
  }
}
