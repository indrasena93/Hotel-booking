package com.newyorklife.webservice.datamap;

import com.newyorklife.schemas.cim.client.clientprofile.clientprofile_10.ClientProfileType;
import com.newyorklife.schemas.cim.common.codetype_1.CodeType;
import com.newyorklife.schemas.cim.common.party_6.PartyType;
import com.newyorklife.schemas.cim.producer.producerprofile_9.ProducerProfileType;
import com.newyorklife.schemas.framework.status_1.StatusType;
import com.newyorklife.schemas.framework.statusmessage_2.StatusMessageType;
import com.newyorklife.services.businessdomain.relationshipmanagement.clientrequestsresponses_11.ClientProfileStatusType;
import com.newyorklife.services.businessdomain.relationshipmanagement.producerrelationshiprequestsresponses_1.AssignProducerByClientIDResponseType;
import com.newyorklife.webservice.businesslogic.ProducerPeckingOrderLogic;
//import com.newyorklife.webservice.dto.ConsumerContractProducerProfile;
import com.nyl.dao.consumer.ConsumerMatchProperties;
import com.nyl.ed.consumer.Address;
import com.nyl.ed.consumer.ConsumerContractProducerProfile;
import com.nyl.ed.shared.State;
import com.nyl.frameworks.datatype.NYLDate;
import com.nyl.frameworks.datatype.NYLDateUtility;
import java.util.Calendar;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ClientDataMap {
	private static final Logger log = LoggerFactory.getLogger(ClientDataMap.class);
  public static Address mapAddress(String paramString1, String paramString2, String paramString3, CodeType paramCodeType) {
    State state = new State();
    if (paramCodeType != null) {
      state.setStateCd(mapLowerCaseToUpperCase(paramCodeType.getValue()));
      state.setStateNm(mapLowerCaseToUpperCase(paramCodeType.getName()));
    } 
    Address address = new Address();
    address.setCityAd(paramString1);
    address.setLine1Ad(paramString2);
    address.setPostalCd(paramString3);
    address.setState(state);
    return address;
  }
  
  public static NYLDate mapNYLDate(Calendar paramCalendar) {
    NYLDate nYLDate = new NYLDate();
    if (paramCalendar != null) {
      nYLDate = NYLDateUtility.create(paramCalendar.get(1), paramCalendar.get(2) + 1, paramCalendar.get(5));
      return nYLDate;
    } 
    return null;
  }
  
  public static ConsumerMatchProperties mapLDSProperty() {
    ConsumerMatchProperties consumerMatchProperties = new ConsumerMatchProperties();
    consumerMatchProperties.THRESHOLD_MATCHING = 85;
    consumerMatchProperties.CITY_STATE_EQU = 15;
    consumerMatchProperties.STREET_ADDR1_NEQ = 0;
    consumerMatchProperties.LAST_NAME_TRN = 10;
    consumerMatchProperties.STREET_ADDR1_TRU = 15;
    return consumerMatchProperties;
  }
  
  public static String mapLowerCaseToUpperCase(String paramString) {
    if (paramString == null)
      return ""; 
    return paramString.toUpperCase();
  }
  
  public static ClientProfileStatusType mapClientProfileStatus(String paramString) {
    ClientProfileStatusType clientProfileStatusType = new ClientProfileStatusType();
    ClientProfileType clientProfileType = new ClientProfileType();
    PartyType partyType = new PartyType();
    StatusMessageType statusMessageType = new StatusMessageType();
    if (paramString.equals("NO_DATA_FOUND")) {
      statusMessageType.setStatusCd(StatusType.NO_DATA_FOUND);
      clientProfileStatusType.setStatusMessage(statusMessageType);
    } else if (paramString.equals("FAILURE")) {
      statusMessageType.setStatusCd(StatusType.FAILURE);
      clientProfileStatusType.setStatusMessage(statusMessageType);
    } else {
      partyType.setPartyId(paramString);
      clientProfileType.setParty(partyType);
      statusMessageType.setStatusCd(StatusType.SUCCESS);
      clientProfileStatusType.setStatusMessage(statusMessageType);
      clientProfileStatusType.getClientProfile().add(clientProfileType);
    } 
    return clientProfileStatusType;
  }
  
  public static AssignProducerByClientIDResponseType.ProducerProfileAndStatusType mapProducerProfileAndStatus(ConsumerContractProducerProfile[] paramArrayOfConsumerContractProducerProfile, String paramString) {
	  log.info("Executing ClientDataMap ...");
    AssignProducerByClientIDResponseType.ProducerProfileAndStatusType producerProfileAndStatusType = new AssignProducerByClientIDResponseType.ProducerProfileAndStatusType();
    ProducerProfileType producerProfileType = new ProducerProfileType();
    StatusMessageType statusMessageType = new StatusMessageType();
    if (paramString.equals("NO_DATA_FOUND")) {
      statusMessageType.setStatusCd(StatusType.NO_DATA_FOUND);
      producerProfileAndStatusType.setStatusMessage(statusMessageType);
    } else if (paramString.equals("FAILURE")) {
      statusMessageType.setStatusCd(StatusType.FAILURE);
      producerProfileAndStatusType.setStatusMessage(statusMessageType);
    } else {
      producerProfileType.getProducerId().add(ProducerPeckingOrderLogic.getProducer(paramArrayOfConsumerContractProducerProfile));
      if (producerProfileType.getProducerId().get(0) == null) {
        statusMessageType.setStatusCd(StatusType.NO_DATA_FOUND);
        producerProfileAndStatusType.setStatusMessage(statusMessageType);
      } else {
        statusMessageType.setStatusCd(StatusType.SUCCESS);
        producerProfileAndStatusType.setStatusMessage(statusMessageType);
      }
      
      if(producerProfileType.getProducerId().get(0) != null) {
    	  producerProfileAndStatusType.setProducerProfile(producerProfileType); 
      }
      
      
    } 
    return producerProfileAndStatusType;
  }
}
