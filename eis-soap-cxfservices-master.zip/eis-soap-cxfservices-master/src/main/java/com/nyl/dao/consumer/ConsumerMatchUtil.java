package com.nyl.dao.consumer;

/**
 * This class is used by the ConsumerMatchDAO, it contains comparison utilities and constants.
 */
public class ConsumerMatchUtil {
	
	private static final int EQUAL = 0;
	private static final int NOT_EQUAL = -1;
	private static final int TRANSPOSITION_MATCH = +1;
	private static final int TRUNCATION_MATCH = +2;
	private static final int ALTERATION_MATCH = +3;
	private static final int INSERTION_MATCH = +4;
	private static final int MULTI_CHAR_INSERTION_MATCH = +5;
	
	private ConsumerMatchUtil() { }

	public static int compareValues(ConsumerMatchWeights weights, String value1, String value2, float maxTruncPc) {
		return compareValues(weights, compareStrings(value1, value2, maxTruncPc), false);
	}
	
	public static int compareValues(ConsumerMatchWeights weights, String value1, String value2, float maxTruncPc, boolean noWeightForMismatch) {
		return compareValues(weights, compareStrings(value1, value2, maxTruncPc), noWeightForMismatch);
	}
	
	public static int compareValues(ConsumerMatchWeights weights, int compareValue, boolean noWeightForMismatch) {
		int weight = 0;
		switch (compareValue) {
		case NOT_EQUAL:
			if (noWeightForMismatch)
				weight = 0;
			else
				weight = weights.getNeq();
			break;
		case EQUAL:
			weight = weights.getEqu();
			break;
		case TRANSPOSITION_MATCH:
			weight = weights.getTrn();
			break;
		case TRUNCATION_MATCH:
			weight = weights.getTru();
			break;
		case ALTERATION_MATCH:
			weight = weights.getAlt();
			break;
		case INSERTION_MATCH:
			weight = weights.getIns();
			break;
		case MULTI_CHAR_INSERTION_MATCH:
			weight = weights.getMci();
			break;
		default:
			weight = 0;
		}
		return weight;	
	}

	public static int compareStrings(String str1, String str2, float maxTruncPc) {
		
		// If any of the string is null, return NOT_EQUAL. If both are null, return EQUAL
		if (null == str1 && null == str2)
			return EQUAL;
		if (null == str1 || null == str2)
			return NOT_EQUAL;
		
		int shortLength, longLength, compareLength, mismatchedAt = 0;
		float actualTruncation;
		char[] shortChars, longChars;
		int str1Length = str1.length();
		int str2Length = str2.length();

		if (str1Length < str2Length) {
			shortLength = str1Length;
			longLength = str2Length;
			shortChars = str1.toCharArray();
			longChars = str2.toCharArray();
		} else {
			shortLength = str2Length;
			longLength = str1Length;
			shortChars = str2.toCharArray();
			longChars = str1.toCharArray();
		}
		if (longLength == 0)
			actualTruncation = 0f;
		else
			actualTruncation = ((float) longLength - (float) shortLength) / (float) longLength;

		// Compare the string character by character
		for (int i = 0; i < shortChars.length; i++) {
			if (shortChars[i] != longChars[i]) {
				mismatchedAt = i + 1;
				break;
			}
		}
		compareLength = shortLength - mismatchedAt;

		if (mismatchedAt == 0) {
			if (actualTruncation <= maxTruncPc)
				return EQUAL;
			if (actualTruncation > 0.0f)
				return TRUNCATION_MATCH;
		} else {
			if (actualTruncation <= maxTruncPc) {
				/**
				 * Check if the short string matches with first part of Long
				 * string ie. xxx matches with xxxYZ (within allowed truncation)
				 */
				// System.out.println("Check for Alteration Match...");
				if (mismatchedAt == shortLength)
					return ALTERATION_MATCH;
				if (new String(longChars, mismatchedAt, compareLength).equals((new String(shortChars, mismatchedAt, compareLength))))
					return ALTERATION_MATCH;

				// System.out.println("Check for Tranposition Match...");
				/**
				 * Check for Tranposition Match a) Check if the mismatched
				 * letter is being flipped
				 */
				if (longChars[mismatchedAt - 1] == shortChars[mismatchedAt] && longChars[mismatchedAt] == shortChars[mismatchedAt - 1])
					/**
					 * The mismatched character is the lst character of shorter
					 * string ie. i.e xxxxYZxxx vs. xxxxZY
					 */
					if (shortLength == mismatchedAt)
						return TRANSPOSITION_MATCH;
					else
					/**
					 * Rest of the charcters after the next charcter of the
					 * mismatched chracter is same i.e xxxxYZxxx vs. xxxxZYxxx
					 */
					if (new String(longChars, mismatchedAt + 1, compareLength - 1).equals((new String(shortChars, mismatchedAt + 1, compareLength - 1))))
						return TRANSPOSITION_MATCH;

				/**
				 * Check for INSERTION Match If the Longer string is just 1 char
				 * longer than shorter and rest of the characters after the
				 * mismatched one are same. ie. xxxxYzzzz vs. xxxxzzzz
				 */
				// System.out.println("Check for INSERTION_MATCH...");
				if (longLength == shortLength + 1
						&& (new String(longChars, mismatchedAt, compareLength + 1).equals((new String(shortChars, mismatchedAt - 1, compareLength + 1)))))
					return INSERTION_MATCH;

				/**
				 * Check for MULTIPLE INSERTION Flag Check if all the characters
				 * after mismatched one matches with the last part of the Longer
				 * string ie. xxxxYYYzzzz vs xxxxzzzz
				 */
				// System.out.println("Check for
				// MULTI_CHAR_INSERTION_MATCH...");
				if (0 < (new String(longChars)).indexOf((new String(shortChars)).substring(mismatchedAt - 1), mismatchedAt))
					return MULTI_CHAR_INSERTION_MATCH;

				return NOT_EQUAL;
			} else {
				/**
				 * Insertion Match The Longer String has just 1 character more
				 * than shorter and rest are same ie. xxxYzzzzzzzzz vs.
				 * xxxzzzzzzzzz
				 */
				if (longLength == shortLength + 1) {
					// check for cases like xxxY xxxZZ
					// Compare rest of the string one by one.
					for (int i = mismatchedAt; i < mismatchedAt + compareLength; i++) {
						if (shortChars[i - 1] != longChars[i]) {
							return NOT_EQUAL;
						}
					}
					return INSERTION_MATCH;
				}
			}
		}
		return NOT_EQUAL;
	}
	
}
