package com.nyl.dao.consumer;

import java.util.Date;

import com.nyl.dao.shared.NylDaoUtil;
import com.nyl.frameworks.datatype.NYLDate;
import com.nyl.frameworks.util.NYLStringUtility;

/**
 * This class is used to hold arguments to SQL queries as well as temporary results from SQL queries.
 */
public class ConsumerMatchCriteria {

	private String clientId;
	private String lastNm;
	private String firstNm;
	private String fullNm;
	private String marketerId;
	private NYLDate birthDt;
	private String taxId;
	private String addressLine;
	private String postalCd;
	private String typeCd;
	private String city;
	private String state;
	
	public ConsumerMatchCriteria() { }
	
	public String getAddressLine() {
		return addressLine;
	}
	
	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public void setAddressLine(String addressLine) {
		this.addressLine = addressLine;
	}
	
	public NYLDate getBirthDt() {
		return birthDt;
	}
	public void setBirthDt(NYLDate birthDt) {
		this.birthDt = birthDt;
	}
	
	public Date getBirthDate() {
		if (birthDt == null) return null;
		return birthDt.getDate();
	}
	public void setBirthDate(Date birthDate) {
		this.birthDt = new NYLDate(birthDate);
	}
	
	public String getFirstNm() {
		return firstNm;
	}
	public String getFirstInitialLike() {
		if (firstNm == null) return null;
		return (firstNm.toUpperCase().substring(0,1) + "%");
	}
	public String getFirstNmLike() {
		if (firstNm == null) return null;
		return (firstNm.toUpperCase() + "%");
	}
	public void setFirstNm(String firstNm) {
		this.firstNm = firstNm;
	}
	
	public String getLastNm() {
		return lastNm;
	}
	public String getLastNmLike() {
		if (lastNm == null) return null;
		return (lastNm.toUpperCase()+"%");
	}
	public void setLastNm(String lastNm) {
		this.lastNm = lastNm;
	}
	
	public String getFullNm() {
		return fullNm;
	}

	public void setFullNm(String fullNm) {
		this.fullNm = fullNm;
	}

	public String getPostalCd() {
		return postalCd;
	}
	public void setPostalCd(String postalCd) {
		this.postalCd = postalCd;
	}

	public String getTaxId() {
		return taxId;
	}
	public void setTaxId(String taxId) {
		this.taxId = taxId;
	}

	public String getTypeCd() {
		return typeCd;
	}

	public void setTypeCd(String typeCd) {
		this.typeCd = typeCd;
	}
	
	public String getMarketerId() {
		return marketerId;
	}

	public void setMarketerId(String marketerId) {
		this.marketerId = marketerId;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("[ConsumerMatchCriteria: ");
		buffer.append("lastNm=").append(lastNm).append(", ");
		buffer.append("firstNm=").append(firstNm).append(", ");
		if (!NYLStringUtility.isEmpty(marketerId)) buffer.append("marketerId=").append(marketerId).append(", ");
		buffer.append("taxId=").append(NylDaoUtil.maskTaxId(taxId)).append(", ");
		buffer.append("birthDt=").append(NylDaoUtil.dateToString(birthDt, true)).append(", ");
		buffer.append("addressLine=").append(addressLine);
		buffer.append("]");
		return buffer.toString();
	}

}
