package com.nyl.dao.consumer;

/**
 * This bean class holds the relevant weight values for comparison.
 */
public class ConsumerMatchWeights {

	String prefix = null;
	int equ = 0;
	int tru = 0;
	int alt = 0;
	int ins = 0;
	int trn = 0;
	int neq = 0;
	int mci = 0;
	
	public ConsumerMatchWeights(String prefix) {
		this.prefix = prefix;
	}

	public String getPrefix() {
		return prefix;
	}

	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}

	public int getAlt() {
		return alt;
	}

	public void setAlt(int alt) {
		this.alt = alt;
	}

	public int getEqu() {
		return equ;
	}

	public void setEqu(int equ) {
		this.equ = equ;
	}

	public int getIns() {
		return ins;
	}

	public void setIns(int ins) {
		this.ins = ins;
	}

	public int getMci() {
		return mci;
	}

	public void setMci(int mci) {
		this.mci = mci;
	}

	public int getNeq() {
		return neq;
	}

	public void setNeq(int neq) {
		this.neq = neq;
	}

	public int getTrn() {
		return trn;
	}

	public void setTrn(int trn) {
		this.trn = trn;
	}

	public int getTru() {
		return tru;
	}

	public void setTru(int tru) {
		this.tru = tru;
	}

	
}
