#!/bin/bash

if [ $# -lt 2 ]; then
	echo "Usage <was artifact jar> <application name>"
	exit -1
fi

if [ -z $1 ]; then
	echo "Please provide the artifact"
	exit -1
fi

if [ ! -f $1 ]; then
	echo "Cannot find provided file $1"
	exit -1
fi

wget -nv -q https://qa.toolsmirror.eis.nylcloud.com/artifactory/eis-software/com/nyl/eis/mulecd/local/mulecd-local-deploy-config.json

BASE_PATH=/c/NYL_WAS/Batch1/ms-local-platform
Environment=dev
ROLEID=`cat mulecd-local-deploy-config.json | jq -r '."vault.role-id"'`
SECRETID=`cat mulecd-local-deploy-config.json | jq -r '."vault.secret-id"'`
CONSUL_ACL=`cat mulecd-local-deploy-config.json | jq -r '."consul.acl"'`
CONSUL_HOST=https://dev.consul.eis.nylcloud.com
VAULT_HOST=https://dev.vault.eis.nylcloud.com

if [[ -z "$ROLEID" || -z "$SECRETID" || -z "$CONSUL_ACL" ]]; then
	echo "Cannot proceed with configuration. Cannot find required configs. Please contact EIS_DevOps_Team@newyorklife.com for further assistance"
	exit -1
fi

echo "Generating credentials and uploading properties to consul"
java -jar $BASE_PATH/tools/jar2consul.jar -Djar=$1 -DappName=$2 -Denv=$Environment -Dvault.role-id=${ROLEID} -Dvault.secret-id=${SECRETID} -Dvault.host=${VAULT_HOST} -Dconsul.url=${CONSUL_HOST} -Dconsul.acl=${CONSUL_ACL}
if [ $? -lt 0 ]; then
	echo "Jar2Consul failed to generate bootstrap yaml"
	exit -1
fi

echo "Uploading vault properties"
java -jar $BASE_PATH/tools/jar2vault.jar --pushkv --jar=$1 --env=$Environment --bootstrap-location=./bootstrap-${Environment}.yml
if [ $? -lt 0 ]; then
	echo "Jar2Vault failed to push secure properties"
	exit -1
fi
cat<< EOF >>./bootstrap-${Environment}.yml
was:
  config-service:
    url: _URL_
    client-id: _ID_
    client-secret: _SECRET_
EOF
URL=`cat mulecd-local-deploy-config.json | jq -r '."mule.config-service.url"'`
ID=`cat mulecd-local-deploy-config.json | jq -r '."mule.config-service.client-id"'`
SECRET=`cat mulecd-local-deploy-config.json | jq -r '."mule.config-service.client-secret"'`
sed -i "s,_URL_,$URL,g" bootstrap-${Environment}.yml
sed -i "s/_ID_/$ID/g" bootstrap-${Environment}.yml
sed -i "s/_SECRET_/$SECRET/g" bootstrap-${Environment}.yml
rm ./mulecd-local-deploy-config.json
echo "bootstrap-${Environment}.yml is complete"